import random

a = random.randint(1,7)


b = random.randint(1,7)


if a ==7 or b==2:
    print("swap")
elif a ==5 or b==5:
    print("bond")
else:
    print("nothing found")