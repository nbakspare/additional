import json
import subprocess
from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
from datetime import datetime as dt
import pandas as pd
from xbbg import blp
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime as dt
from datetime import timedelta as td
import statsmodels.api as sm
import re
import matplotlib.image as image
from ipywidgets import interact, IntSlider, Checkbox, Dropdown, Output, HBox, VBox, interactive, interactive_output, ToggleButton,Text, Button, DatePicker, IntText, ToggleButtons, RadioButtons,SelectMultiple
from IPython.display import display, clear_output
import itertools
from scipy import stats
from scipy.optimize import minimize 
from scipy.special import ndtr
import base64
import io
from statsmodels.tools.tools import add_constant
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.seasonal import STL
import random
import matplotlib
matplotlib.use('Agg')

app = Flask(__name__)

spot_library = {'eur_6':['EUSA', ' Curncy'],'eur': ['EESWE', ' Curncy'], 'usd': ['USOSFR', ' Curncy'], 
                'gbp': ['BPSWS', ' Curncy'],'chf': ['SFSNT', ' Curncy'],'sek': ['SKSW', ' Curncy'],
                 'nok': ['NKSW', ' Curncy'], 'hkd': ['HDSW', ' Curncy'],'czk': ['CKSW', ' Curncy'],
                 'pln': ['PZSW', ' Curncy'],'ils':['ISSW', ' Curncy'],  'cad':['CDSW', ' Curncy'], 
                 'jpy':['JYSO', ' Curncy'], 'aud': ['ADSW', ' Curncy'],'sgd':['SDSW', ' Curncy'],
                'krw': ['KWSWNI', ' Curncy'],
                'zar': ['SASW', ' Curncy'],
                'nzd': ['NDSW', ' Curncy'],
                'mxn': ['MPSW', ' Curncy']} 

forward_library = {'eur_6': ['EUSA', ' Curncy'], 
                 'eur': ['S0514FS ', ' BLC Curncy'], 
                 'usd': ['S0490FS ', ' BLC Curncy'], 
                 'gbp': ['S0141FS ', ' BLC Curncy'],
                 'chf': ['S0234FS ', ' BLC Curncy'],
                 'sek': ['SD0020FS ', ' BLC Curncy'],
                 'nok': ['SD0313FS ', ' BLC Curncy'],
                 'hkd': ['HDFS', ' Curncy'],
                 'czk': ['S0320FS ', ' BLC Curncy'],
                 'pln': ['S0323FS ', ' BLC Curncy'],
                 'ils': ['ISFS', ' Curncy'],
                 'cad': ['S0147FS ', ' BLC Curncy'],
                 'jpy': ['S0195FS ', ' BLC Curncy'],
                 'aud': ['SD0302FS ', ' BLC Curncy'],
                'sgd': ['SDFS', ' Curncy'],
                'krw': ['S0205FS ', ' BLC Curncy'],
                'zar': ['SAFS', ' Curncy'],#
                'nzd': ['SD0015FS ', ' BLC Curncy'],
                'mxn': ['SD0083FS ', ' BLC Curncy']} 

idx = ['estr','sofr','sonia', 'saron','jibar','euribor','stibor','nibor','telbor','pribor','wibor']
cols = ['1Y','1Y1Y','2Y1Y','3Y1Y', '4Y1Y','5Y1Y','6Y1Y','7Y1Y', '8Y1Y', '9Y1Y', '10Y2Y', '12Y3Y', '15Y5Y', '20Y5Y', '25Y5Y', '30Y10Y']
curves = pd.DataFrame({0:['EESWE1 Curncy', 'S0514FS 1Y1Y BLC Curncy','S0514FS 2Y1Y BLC Curncy', 'S0514FS 3Y1Y BLC Curncy','S0514FS 4Y1Y BLC Curncy', 'S0514FS 5Y1Y BLC Curncy','S0514FS 6Y1Y BLC Curncy', 'S0514FS 7Y1Y BLC Curncy','S0514FS 8Y1Y BLC Curncy', 'S0514FS 9Y1Y BLC Curncy','S0514FS 10Y2Y BLC Curncy', 'S0514FS 12Y3Y BLC Curncy','S0514FS 15Y5Y BLC Curncy', 'S0514FS 20Y5Y BLC Curncy','S0514FS 25Y5Y BLC Curncy', 'S0514FS 30Y10Y BLC Curncy'], 
          1:['USOSFR1 Curncy', 'S0490FS 1Y1Y BLC Curncy','S0490FS 2Y1Y BLC Curncy', 'S0490FS 3Y1Y BLC Curncy','S0490FS 4Y1Y BLC Curncy', 'S0490FS 5Y1Y BLC Curncy','S0490FS 6Y1Y BLC Curncy', 'S0490FS 7Y1Y BLC Curncy','S0490FS 8Y1Y BLC Curncy', 'S0490FS 9Y1Y BLC Curncy','S0490FS 10Y2Y BLC Curncy', 'S0490FS 12Y3Y BLC Curncy','S0490FS 15Y5Y BLC Curncy', 'S0490FS 20Y5Y BLC Curncy','S0490FS 25Y5Y BLC Curncy', 'S0490FS 30Y10Y BLC Curncy'],
         2:['BPSWS1 Curncy', 'S0141FS 1Y1Y BLC Curncy','S0141FS 2Y1Y BLC Curncy', 'S0141FS 3Y1Y BLC Curncy','S0141FS 4Y1Y BLC Curncy', 'S0141FS 5Y1Y BLC Curncy','S0141FS 6Y1Y BLC Curncy', 'S0141FS 7Y1Y BLC Curncy','S0141FS 8Y1Y BLC Curncy', 'S0141FS 9Y1Y BLC Curncy','S0141FS 10Y2Y BLC Curncy', 'S0141FS 12Y3Y BLC Curncy','S0141FS 15Y5Y BLC Curncy', 'S0141FS 20Y5Y BLC Curncy','S0141FS 25Y5Y BLC Curncy', 'S0141FS 30Y10Y BLC Curncy'],
          3:['SFSNT1 Curncy', 'S0234FS 1Y1Y BLC Curncy','S0234FS 2Y1Y BLC Curncy', 'S0234FS 3Y1Y BLC Curncy','S0234FS 4Y1Y BLC Curncy', 'S0234FS 5Y1Y BLC Curncy','S0234FS 6Y1Y BLC Curncy', 'S0234FS 7Y1Y BLC Curncy','S0234FS 8Y1Y BLC Curncy', 'S0234FS 9Y1Y BLC Curncy','S0234FS 10Y2Y BLC Curncy', 'S0234FS 12Y3Y BLC Curncy','S0234FS 15Y5Y BLC Curncy', 'S0234FS 20Y5Y BLC Curncy','S0234FS 25Y5Y BLC Curncy', float("nan")],
        4:['SASW1 Curncy', 'SAFS0101 Curncy', 'SAFS0201 Curncy','SAFS0301 Curncy', 'SAFS0401 Curncy', 'SAFS0501 Curncy','SAFS0601 Curncy', 'SAFS0701 Curncy', 'SAFS0801 Curncy','SAFS0901 Curncy', 'SAFS1002 Curncy', 'SAFS1203 Curncy','SAFS1505 Curncy', 'SAFS2005 Curncy', 'SAFS2505 Curncy', float("nan")],
         5:['EUSA1 Curncy', 'EUSA0101 Curncy', 'EUSA0201 Curncy','EUSA0301 Curncy', 'EUSA0401 Curncy', 'EUSA0501 Curncy','EUSA0601 Curncy', 'EUSA0701 Curncy', 'EUSA0801 Curncy','EUSA0901 Curncy', 'EUSA1002 Curncy', 'EUSA1203 Curncy','EUSA1505 Curncy', 'EUSA2005 Curncy', 'EUSA2505 Curncy', 'EUSA3010 Curncy'],
         6: ['SKSW1 Curncy', 'SD0020FS 1Y1Y BLC Curncy','SD0020FS 2Y1Y BLC Curncy', 'SD0020FS 3Y1Y BLC Curncy','SD0020FS 4Y1Y BLC Curncy', 'SD0020FS 5Y1Y BLC Curncy','SD0020FS 6Y1Y BLC Curncy', 'SD0020FS 7Y1Y BLC Curncy','SD0020FS 8Y1Y BLC Curncy', 'SD0020FS 9Y1Y BLC Curncy','SD0020FS 10Y2Y BLC Curncy', 'SD0020FS 12Y3Y BLC Curncy','SD0020FS 15Y5Y BLC Curncy', 'SD0020FS 20Y5Y BLC Curncy','SD0020FS 25Y5Y BLC Curncy', float("nan")],
         7: ['NKSW1 Curncy', 'SD0313FS 1Y1Y BLC Curncy','SD0313FS 2Y1Y BLC Curncy', 'SD0313FS 3Y1Y BLC Curncy','SD0313FS 4Y1Y BLC Curncy', 'SD0313FS 5Y1Y BLC Curncy','SD0313FS 6Y1Y BLC Curncy', 'SD0313FS 7Y1Y BLC Curncy','SD0313FS 8Y1Y BLC Curncy', 'SD0313FS 9Y1Y BLC Curncy','SD0313FS 10Y2Y BLC Curncy', 'SD0313FS 12Y3Y BLC Curncy','SD0313FS 15Y5Y BLC Curncy', 'SD0313FS 20Y5Y BLC Curncy','SD0313FS 25Y5Y BLC Curncy', float('nan')],
         8: ['ISSW1 Curncy', 'ISFS0101 Curncy', 'ISFS0201 Curncy','ISFS0301 Curncy', 'ISFS0401 Curncy', 'ISFS0501 Curncy','ISFS0601 Curncy', 'ISFS0701 Curncy', 'ISFS0801 Curncy','ISFS0901 Curncy', 'ISFS1002 Curncy', 'ISFS1203 Curncy','ISFS1505 Curncy', 'ISFS2005 Curncy', 'ISFS2505 Curncy', float('nan')],
         9: ['CKSW1 Curncy', 'S0320FS 1Y1Y BLC Curncy','S0320FS 2Y1Y BLC Curncy', 'S0320FS 3Y1Y BLC Curncy','S0320FS 4Y1Y BLC Curncy', 'S0320FS 5Y1Y BLC Curncy','S0320FS 6Y1Y BLC Curncy', 'S0320FS 7Y1Y BLC Curncy','S0320FS 8Y1Y BLC Curncy', 'S0320FS 9Y1Y BLC Curncy','S0320FS 10Y2Y BLC Curncy', 'S0320FS 12Y3Y BLC Curncy', float('nan'), float('nan'),float('nan'), float('nan')],
         10: ['PZSW1 Curncy', 'S0323FS 1Y1Y BLC Curncy','S0323FS 2Y1Y BLC Curncy', 'S0323FS 3Y1Y BLC Curncy','S0323FS 4Y1Y BLC Curncy', 'S0323FS 5Y1Y BLC Curncy','S0323FS 6Y1Y BLC Curncy', 'S0323FS 7Y1Y BLC Curncy','S0323FS 8Y1Y BLC Curncy', 'S0323FS 9Y1Y BLC Curncy','S0323FS 10Y2Y BLC Curncy', float('nan'), float('nan'), float('nan'),float('nan'), float('nan')] 
            }).T


#curves = pd.DataFrame(data).T

curves.columns = cols
curves.index = idx

################################################# SWAP STRUCTURE BUILDERS ################################################

def cut(some):
    x = 0
    y = some[0]
    while y.isdigit():
        y=some[x]
        x+=1
    return some[:x],some[x:]


def f(tenor):
    x = re.findall(r'\d+',tenor)[0]
    num = ''
    if 'm' in tenor.lower():
        if int(x) // 12 >0:
            num+='1'
        num+=chr(64+(int(x)%12))
    else:
        if len(x) == 1:
            num+='0'
        num +=x
    return num

def t(tenor):
    x = re.findall(r'\d+',tenor)[0]
    num = ''
    if 'm' in tenor.lower():
        if int(x) // 12 >0:
            num+='1'
        else:
            num+='0'
        num+=chr(64+(int(x)%12))
    else:
        if len(x) == 1:
            num+='0'
        num +=x
    return num


def spot_ticker(dex,tenor):
    if dex.lower() == 'mxn':
        y = int(tenor[:-1]) * 13
        num = f'{y//12}{chr(64+(y%12))}'
    else:
        num = tenor[:-1]
    return f'{spot_library[dex][0]}{num}{spot_library[dex][1]}'

def forward_ticker(dex,fwd):
    dex = dex.lower()
    fwd = fwd.lower()
    old = ['eur_6','hkd','ils','sgd','zar']
    
    if cut(fwd)[0] == '0y':
        return spot_ticker(dex,cut(fwd)[1])
    elif dex == 'eur_6':
        F,T = f(cut(fwd)[0]),t(cut(fwd)[1])
        return f'{forward_library[dex][0]}{F}{T}{forward_library[dex][1]}'
    elif dex in old:
        F,T = t(cut(fwd)[0]),t(cut(fwd)[1])
        return f'{forward_library[dex][0]}{F}{T}{forward_library[dex][1]}'
    else:
        
        return f'{forward_library[dex][0]}{fwd.upper()}{forward_library[dex][1]}'


def swap_structure(dex,structure,start, end = 'today',bps = True):
    print(start, end)
    f_fly = structure.count('/') == 2
    f_crv = structure.count('/') == 1  
    fly = structure.count('s') == 3
    crv = structure.count('s') == 2
    out = max(2 -sum([i.isalpha() for i in structure]),0)
    
    if f_fly or f_crv:
        legs = [forward_ticker(dex,i) for i in structure.split('/')]
    elif fly or crv:
        legs = [spot_ticker(dex,i) for i in [i+'Y' for i in structure.split('s') if i.isdigit()]]
    else:
        legs = forward_ticker(dex,('0Y'*out) + structure)
        
    print(legs)
    df = blp.bdh(legs, flds='px_last', start_date=start,end_date=end).fillna(method ='bfill')  *(100 if bps else 1)
    print(df)
    s  = pd.DataFrame({})
    if f_fly or fly:
        x = (2 * df.iloc[:,1]) - (df.iloc[:,0] + df.iloc[:,2])
    elif f_crv or crv:
        x = df.iloc[:,1] - df.iloc[:,0]
    else:
        x = df.iloc[:,0]
        
    s[f'{dex.upper()} {structure}'] = x
    return s

def structure(dex,structure,start, end = 'today',bps = True):
    f_fly = structure.count('/') == 2
    f_crv = structure.count('/') == 1  
    fly = structure.count('s') == 3
    crv = structure.count('s') == 2
    out = max(2 -sum([i.isalpha() for i in structure]),0)
    
    if f_fly or f_crv:
        legs = [forward_ticker(dex,i) for i in structure.split('/')]
    elif fly or crv:
        legs = [spot_ticker(dex,i) for i in [i+'Y' for i in structure.split('s') if i.isdigit()]]
    else:
        legs = forward_ticker(dex,('0Y'*out) + structure)
        
    df = blp.bdh(legs, flds='px_last', start_date=start,end_date=end)  *(100 if bps else 1)
    s  = pd.DataFrame({})
    if f_fly or fly:
        x = (2 * df.iloc[:,1]) - (df.iloc[:,0] + df.iloc[:,2])
    elif f_crv or crv:
        x = df.iloc[:,1] - df.iloc[:,0]
    else:
        x = df.iloc[:,0]
        
    s[f'{dex.upper()} {structure}'] = x
    return s

def threeM_roll(structure): # only valid for >=1y f
    fds = [int(i.split('y')[0])*12 -3 for i in structure.split('/')]
    act = [int(i.split('y')[1]) for i in structure.split('/')]
    roll_to = [f'{i}M{j}Y' for i,j in zip(fds,act)]
    new_structure =''
    for i in range(len(roll_to)):
        if i !=0:
            new_structure += '/'    
        new_structure += roll_to[i]
    return new_structure

################################################# BOND STRUCTURE BUILDERS ################################################
def bond_ticker(bond_name, bond_tenor):
    cmb = {'ust':1,'dbr':2,'spgb':8,'frtr':4,'btp':5,'ukt':6}
    return f'RV000{cmb[bond_name]}P {bond_tenor.upper()} BLC Curncy'

def bond_structure(bonds,structure, start, end = 'today'):
    if '-' in bonds:
        s = pd.DataFrame({})
        bond1,bond2 = bonds.split('-')
        s[f'{bonds.upper()} {structure}'] = bond_structure(bond1,structure, start, end)[f'{bond1.upper()} {structure}'] - bond_structure(bond2,structure, start, end)[f'{bond2.upper()} {structure}']
        return s
    else:
        if 'y' in structure.lower(): #bond o/r
            tickers = bond_ticker(bonds.lower(), structure)
            base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
            base.columns = [f'{bonds.upper()} {structure}']
            return base
        
        elif structure.lower().count('s') == 2: #bond curve
            tickers = [bond_ticker(bonds.lower(), f'{i}y') for i in structure.lower().split('s') if i != '']
            base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
            base.columns = tickers
            s = pd.DataFrame({})
            s[f'{bonds.upper()} {structure}'] = base[tickers[1]] - base[tickers[0]]
            return s
        
        elif structure.lower().count('s') == 3: # bond fly
            tickers = [bond_ticker(bonds.lower(), f'{i}y') for i in structure.lower().split('s') if i != '']
            base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
            base.columns = tickers
            s = pd.DataFrame({})
            s[f'{bonds.upper()} {structure}'] = (2*base[tickers[1]]) - (base[tickers[0]] + base[tickers[2]])
            return s

################################################# FUTURES STRUCTURE BUILDERS ################################################

def fut_ticker(dex, contract, name = False):
    x  = ''
    if dex.lower()[:3] == 'eur':
        x = 'ER'
    elif dex.lower() == 'usd':
        x = 'SFR'
    elif dex.lower() == 'gbp':
        x = 'SFI'
    
    if name:
        return x
    else:
        return f'{x}{contract} Comdty'   
           
    
def fut_structure(dex,structure, start, end = 'today'):
    name = fut_ticker(dex.lower(), 0,True)
    
    if structure.lower().count('s') == 2: #fut curve
        tickers = [fut_ticker(dex.lower(), int(i)) for i in structure.lower().split('s') if i != '']
        base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
        base.columns = tickers
        s = pd.DataFrame({})
        s[f'{name}{structure.replace("s","")}'] = base[tickers[0]] - base[tickers[1]]
        return s
        
    elif structure.lower().count('s') == 3: # fut fly
        tickers = [fut_ticker(dex.lower(), int(i)) for i in structure.lower().split('s') if i != '']
        base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
        base.columns = tickers
        s = pd.DataFrame({})
        s[f'{name}{structure.replace("s","")}'] = (2*base[tickers[1]]) - (base[tickers[0]] + base[tickers[2]])
        return s
    else:
        tickers = fut_ticker(dex.lower(), structure)
        base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
        base.columns = [f'{name}{structure}']
        return base

################################################# ASW STRUCTURE BUILDERS ################################################

def get_asw(bond_name,tenor,start, end ='today',euro = 'estr'):
    asso_swap = {'ust':'usd','dbr':'eur','spgb':'eur','frtr':'eur','btp':'eur','ukt':'gbp'}
    
    if asso_swap[bond_name] == 'eur' and euro != 'estr':
        tickers = [bond_ticker(bond_name,tenor), spot_ticker(asso_swap[bond_name]+'_6',tenor)]
    else:
        tickers = [bond_ticker(bond_name,tenor), spot_ticker(asso_swap[bond_name],tenor)]
    base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
    base.columns = tickers
    s = pd.DataFrame({})
    s[f'{tenor.upper()} {bond_name.upper()} ASW'] = base[tickers[1]] - base[tickers[0]]
    return s

def asw_structure(bonds,structure, start, end = 'today',euro = 'estr'):
    if '-' in bonds:
        s = pd.DataFrame({})
        bond1,bond2 = bonds.split('-')
        s[f'{bonds.upper()} ASW {structure}'] = asw_structure(bond1,structure, start, end,euro)[f'{bond1.upper()} ASW {structure}'] - asw_structure(bond2,structure, start, end,euro)[f'{bond2.upper()} ASW {structure}']
        return s
    else:
        if 'y' in structure.lower(): #asw o/r
            return get_asw(bonds,structure,start, end,euro)
        
        elif structure.lower().count('s') == 2: #asw curve
            legs = [ f'{i}y' for i in structure.lower().split('s') if i != '']
            short_leg, long_leg = [get_asw(bonds,i,start,end,euro) for i in legs]
            df = short_leg.join(long_leg, how = 'inner')
            s = pd.DataFrame({})
            s[f'{bonds.upper()} ASW {structure}'] = df.iloc[:,1]  - df.iloc[:,0]  
            return s
        
        elif structure.lower().count('s') == 3: # asw fly
            legs = [ f'{i}y' for i in structure.lower().split('s') if i != '']
            short_leg, belly ,long_leg = [get_asw(bonds,i,start,end,euro) for i in legs]
            short_leg = short_leg.join(belly, how = 'inner')
            df = short_leg.join(long_leg, how = 'inner')
            s = pd.DataFrame({})
            s[f'{bonds.upper()} ASW {structure}'] = (2 * df.iloc[:,1])  - (df.iloc[:,0] + df.iloc[:,2])  
            return s
        

######################################### TICKER HANDLERS #################################################################

def get_other(ticker,attribute,title,start,end='today' ):
    #print(ticker,attribute,title)
    attribute = 'px_last'
    print(ticker,attribute,title)
    base = blp.bdh(ticker,attribute,start,end)
    base.columns = [title]
    return base

######################################### INVOICE SPREAD STRUCTURE BUILDERS ################################################


def get_ivsp(country,start, end ='today',which = 'TUA',euro ='estr'):
    tkr = {'USD':['TUAISPS','3YAISPS','FVAISPS','TYAISPS','UXYAISPS','USAISPS','WNAISPS'],
           'GER':['DUAISP','OEAISP','RXAISP','UBAISP'],
           'ITA':['BTAISP','IKAISP'],
           'FRA':['OATAISP'],
           'GBP':['GAISPO']}
    
    if country.upper() == 'USD' or country.upper() == 'GER' or country.upper() == 'ITA' :
        for i in tkr[country.upper()]:
            if which in i:
                future = i
    else:
        future = tkr[country.upper()][0]
    
    if country.lower() in ['ger','ita','fra'] and euro == 'estr':
        future += 'E'
    final_ticker = f'{future} Comdty'
    base = blp.bdh(final_ticker,'px_last',start,end)
    base.columns = [f'{future} Comdty']    
    return base
                
######################################## MEETING DATES HANDLER ##################################################################
    
def md_swap_ticker(bank, meeting,m_of_m =False):
    central_bank = {'FOMC':['USSOFED',' Curncy'],
                'ECB':['EESF','A Curncy'],
                'MPC':['GPSF','A Curncy']}
    ticker = f'{central_bank[bank.upper()][0]}{meeting}{central_bank[bank.upper()][1]}' 
    if m_of_m:
        return blp.bdp(ticker, 'SW_EFF_DT').values.flatten()[0].strftime('%b')
    else:
        return ticker
    
def get_md_swap(bank,structure,start,end  = 'today'):
    if structure.lower().count('s') == 2:
        tickers = [md_swap_ticker(bank.upper(),int(i)) for i in structure.lower().split('s') if i != ''] 
        lbls = ''.join([md_swap_ticker(bank.upper(),int(i), True) for i in structure.lower().split('s') if i != ''])
        base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
        base.columns = tickers
        s = pd.DataFrame({})
        s[f'{lbls} {bank.upper()}'] = base[tickers[1]] - base[tickers[0]]
        return s
        
    if structure.lower().count('s') == 3:
        tickers = [md_swap_ticker(bank.upper(),int(i)) for i in structure.lower().split('s') if i != '']
        lbls = ''.join([md_swap_ticker(bank.upper(),int(i), True) for i in structure.lower().split('s') if i != ''])            
        base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
        base.columns = tickers
        s = pd.DataFrame({})
        s[f'{lbls} {bank.upper()}'] = (2*base[tickers[1]] )- (base[tickers[0]] + base[tickers[2]])
        return s
    else:
        tickers = md_swap_ticker(bank.upper(), structure)
        base = blp.bdh(tickers, 'px_last', start, end).fillna(method ='bfill') * 100
        base.columns = [f'{md_swap_ticker(bank.upper(), structure,True)}{bank.upper()}']
        return base

    
################################################# FX HANDLER ############################################################
def get_fx_pair(pair,start,end='today'):
    ticker = f'{pair.upper()} Curncy'
    base = blp.bdh(ticker,'px_last',start,end)
    base.columns = [pair.upper()]
    return base

######################################## BOND FUTURE HANDLER ##################################################################
def get_bondf_ticker(name):
    tic_dic = {'DU':'DUA Comdty','OE':'OEA Comdty','RX': 'RXA Comdty','UB': 'UBA Comdty',
                'BTS': 'BTSA Comdty','IK': 'IKA Comdty',
                'OAT': 'OATA Comdty',
                'G':'G A Comdty',
                'TU': 'TUA Comdty','FV': 'FVA Comdty', 'TY': 'TYA Comdty','WN': 'WNA Comdty','UXY': 'UXYA Comdty'}
    return tic_dic[name.upper()]
    

def get_bond_fut(_str, start,end = 'today', fld = 'yield'):
    fld = 'YLD_YTM_MID' if fld.lower() == 'yield' else 'PX_LAST' 
    _str = _str.upper()
    label = _str.split('/')
    legs = [get_bondf_ticker(i) for i in label]
    bps = 100 if fld == 'YLD_YTM_MID' else 1
    base  = blp.bdh(legs,fld,start,end) * bps
    base.columns = label
    s = pd.DataFrame({})
    
    if _str.count('/') == 2:
        s[_str] = 2 * base[label[1]] - (base[label[0]] + base[label[2]]) 
            
    elif _str.count('/') == 1:
        s[_str] =  base[label[1]] - base[label[0]] 
                                        
    else:
        s = base
        
    return s
    

######################################## INFL SWAP HANDLER ##################################################################

@app.route('/get_options', methods=['POST'])
def get_options():
    instrument = request.json['instrument']
    eugov = ['DBR', 'SPGB', 'FRTR', 'BTP', 'BTP-DBR', 'FRTR-DBR', 'SPGB-DBR', 'BTP-SPGB', 'FRTR-SPGB']
    cix_options = get_cix_options()
    
    options = {
        '-': {'description': 'Choose Instrument', 'fields': []},
        'SWAP': {'options': [i.upper() for i in spot_library.keys()], 'description': 'Currency', 'fields': ['currency']},
        'FUTURE': {'options': ['USD', 'EUR', 'GBP'], 'description': 'Currency', 'fields': ['currency']},
        'BOND': {'options': ['UST', 'DBR', 'SPGB', 'FRTR', 'BTP', 'UKT', 'BTP-DBR', 'FRTR-DBR', 'SPGB-DBR', 'BTP-SPGB', 'FRTR-SPGB'], 'description': 'Bond', 'fields': ['currency']},
        'BOND FUTURE': {'options': ['Yield', 'Price'], 'description': 'Field', 'fields': ['currency']},
        'MD SWAP': {'options': ['FOMC', 'ECB', 'MPC'], 'description': 'Central Bank', 'fields': ['currency']},
        'ASW': {'options': ['UST', 'DBR', 'SPGB', 'FRTR', 'BTP', 'UKT', 'BTP-DBR', 'FRTR-DBR', 'SPGB-DBR', 'BTP-SPGB', 'FRTR-SPGB'], 'description': 'Bond', 'fields': ['currency']},
        'FX': {'description': 'Pair', 'fields': ['currency']},
        'XMKT SWAP': {'options': [i.upper() for i in spot_library.keys()], 'description': 'Currency', 'fields': ['currency']},
        'OTHER/CIX': {'description': 'Ticker', 'fields': ['currency']},
        'MY CIX': {'options': cix_options, 'description': 'Ticker', 'fields': ['currency']}
    }
    
    return jsonify(options[instrument])

######################################## MASTER HANDLER ##################################################################
def get_cix_options():
    if os.path.exists('cix.csv'):
        df = pd.read_csv('cix.csv')
        return df.iloc[:,0].tolist()
    else:
        return []

def function_for_bb(trades,_from,_to):
    master_c = pd.DataFrame({})
    for i in trades.keys():
        if len(trades[i]) != 0:
            for j in trades[i]:
                # TRADES[i] is the TUPLE!
                if i == 'SWAP':
                    h = swap_structure(dex = j[0].lower() ,structure=j[1].lower() ,start = _from , end = _to)                                
                elif i == 'FUTURE':
                    h = fut_structure(dex = j[0].lower() ,structure=j[1].lower() ,start = _from , end = _to)                              
                elif i == 'BOND':
                    h = bond_structure(bonds = j[0].lower() ,structure=j[1].lower() ,start = _from , end = _to)
                elif i ==  'ASW':
                    print(j)
                    h = asw_structure(bonds = j[0].lower() ,structure=j[1].lower() ,start = _from , end = _to, euro = j[2].lower())
                elif i == 'XMKT SWAP':
                    h1 = swap_structure(dex = j[0].lower() ,structure=j[1].lower() ,start = _from , end = _to)
                    h2 = swap_structure(dex = j[2].lower() ,structure=j[1].lower() ,start = _from , end = _to)
                    h_int = h1.join(h2, how = 'inner')
                    h = pd.DataFrame(h_int.iloc[:,0] - h_int.iloc[:,1], columns = [f'{j[0]}-{j[2]} {j[1]}'])
                elif i == 'MD SWAP':
                    h = get_md_swap(bank = j[0].upper(),structure=j[1].lower() ,start = _from , end = _to)
                elif i ==  'BOND FUTURE':
                    h = get_bond_fut(_str = j[0],start = _from , end = _to,fld =  j[1])
                elif i == 'FX':
                    h = get_fx_pair(pair = j[0].upper(),start = _from , end = _to)
                elif i == 'OTHER/CIX':
                    h = get_other(ticker = j[0], attribute= j[1], title = j[2], start = _from , end = _to)            
                elif i == 'MY CIX':
                    #print(j[0], j[0], j[0], _from, _to)
                    h = get_other(ticker = j[0], attribute= j[1], title = j[2], start = _from , end = _to)   
                elif i == 'CREATE CIX':
                    #print(j[0], j[0], j[0], _from, _to)
                    h = get_other(ticker = j[0], attribute= j[1], title = j[2], start = _from , end = _to)  
                if master_c.shape == (0,0):
                    master_c = h
                else:
                    master_c = master_c.join(h, how = 'inner')
    return master_c


clrs = ['whites','reds','greens','blues']
def fut_presets(dex,clr):
    color = {key : range(1+(clrs.index(key)*4),5+(clrs.index(key)*4)) for key in clrs}
    fin_clr = []
    for i in clr.lower().split(', '):
        fin_clr += list(color[i])
    for i in fin_clr:
        yield (dex.upper(), str(i))

clr_dd = [', '.join([m.capitalize() for m in j]) for i in range(1,len(clrs)+1) for j in itertools.combinations(clrs, i) ]


sp_or_fw = ['Spot Tenors', 'Forward Gaps']
yc = ['(up to 10y)','(up to 15y)','(up to 30y)','(up to 50y)']
srt = ['Spot Curves', 'Spot Flys', 'Forward Curves']
swap_ops = [f'{i} {j}' for i in sp_or_fw for j in yc] + srt
bond_ops = ['Outright', 'Curves', 'Flys']

def swap_presets(dex, build):
    
    spot_front = [f'{i}y' for i in range (1,11)]
    spot_mid = spot_front + ['12y','15y']
    spot_back = spot_mid + ['20y','25y','30y']
    spot_ultraback =spot_back + ['40y','50y']
    
    fwds_front = [f'{i}y1y' for i in range (1,10)]
    fwds_mid = fwds_front +['10y2y','12y3y']
    fwds_back = fwds_mid + ['15y5y','20y5y','25y5y']
    fwds_ultraback = fwds_back + ['30y10y','40y10y']
    
    spot_curves = ['1s2s','2s5s','2s10s','5s10s','5s30s','10s30s']
    spot_flys = ['1s2s3s','1s3s5s', '2s5s10s', '5s10s30s']
    fwds_curves = ['1y1y/5y5y','1y2y/1y10y']
    answer = []
    if 'spot' in build.lower():
        if '10y' in build.lower():
            answer = spot_front
        elif '15y' in build.lower():
            answer = spot_mid
        elif '30y' in build.lower():
            answer = spot_back
        elif '50y' in build.lower():
            answer = spot_ultraback
        elif 'curves' in build.lower():
            answer = spot_curves
        elif 'flys' in build.lower():
            answer = spot_flys 
        else:
            answer = spot_curves + spot_flys
    else:
        if '10y' in build.lower():
            answer = fwds_front
        elif '15y' in build.lower():
            answer = fwds_mid
        elif '30y' in build.lower():
            answer = fwds_back
        elif '50y' in build.lower():
            answer = fwds_ultraback
        else:
            answer = fwds_curves
    for i in answer:
        yield(dex.upper(),i)
        
def bond_spline_presets(bond,build):
    answer = {'Outright': ['2y','5y','10y','30y'],
             'Curves': ['2s5s','2s10s','5s10s','5s30s','10s30s'], 
              'Flys':['2s5s10s', '5s10s30s']}
    for i in answer[build]:
        yield (bond.upper(), i)
        
def asw_spline_presets(bond,build,euro = 'ESTR'):
    answer = {'Outright': ['2y','5y','10y','30y'],
             'Curves': ['2s5s','2s10s','5s10s','5s30s','10s30s'], 
              'Flys':['2s5s10s', '5s10s30s']}
    for i in answer[build]:
        yield (bond.upper(), i,euro)

def custom_presets(broker):
    if broker == "MR Presets":
        return {'SWAP': [('USD','2y1y/3y2y/5y2y'),('GBP','2y1y/3y2y/5y2y'),('EUR','2y1y/3y2y/5y2y'),('EUR_6','2y1y/3y2y/5y2y'),
                         ('USD','5y2y/7y3y'),('GBP','5y2y/7y3y'),('EUR','5y2y/7y3y'),('EUR_6','5y2y/7y3y'),
                         ('USD','5s7s10s'),('GBP','5s7s10s'),('EUR','5s7s10s'),('EUR_6','5s7s10s'),
                        ]}

data=pd.read_excel('xkmt.xlsx', index_col=0, parse_dates = True) 
data = data.dropna()

def get_business_day_number(date_str):
    # Convert the input date string to a pandas Timestamp object
    date = pd.to_datetime(date_str)

    # Create a DatetimeIndex with all the business days in the year
    year = date.year
    business_days = pd.date_range(start=f'{year}-01-01', end=f'{year}-12-31', freq='B')

    # Find the closest business day to the input date
    closest_business_day = min(business_days, key=lambda x: abs((x - date).days))

    # Calculate the business day number (0-indexed)
    business_day_number = business_days.get_loc(closest_business_day)

    return business_day_number


def get_business_day_by_number_one(year, business_day_number1):
    business_days = pd.date_range(start=f'{year}-01-01', end=f'{year}-12-31', freq='B')

    if business_day_number1 < 1 or business_day_number1 > len(business_days):
        raise ValueError("Invalid business day number")

    start = business_days[business_day_number1 - 1]

    formatted_date = start.strftime("%m-%d")

    return formatted_date


def get_business_day_by_number(year, business_day_number1, business_day_number2):
    business_days = pd.date_range(start=f'{year}-01-01', end=f'{year}-12-31', freq='B')

    if business_day_number1 < 1 or business_day_number2 > len(business_days):
        raise ValueError("Invalid business day number")

    start = business_days[business_day_number1 - 1]

    formatted_date = start.strftime("%m-%d")
    
    end = business_days[business_day_number2 - 1]

    formatted_date2 = end.strftime("%m-%d")

    return formatted_date, formatted_date2

def pnl_calculator(trade, data, day, type, year, start, end, verbose=False):
    #print("HELOOOOOOO")
    start, end = get_business_day_by_number(year, start, end)
    pnls = []
    data.index = pd.to_datetime(data.index)
    #data = data.asfreq('D')
    #print(data)
    Index = data.index  
    #print(Index)
    Years = list(set(Index.year))
    #print("Years: ", Years)
    Years.sort()
    #print("Years: ", Years)
    Years = list(map(str, Years))
    #print("Years: ", Years)
    df = data.loc[:, trade]
    res = STL(df).fit()
    starts = [str(i) + '-' + start for i in Years]
    ends = [str(i) + '-' + end for i in Years]
    #print("Years: ", Years)
    #print(type)
    if type == 'PAY':

        for i in range(len(Years)):
            try:
                Data_Seasonality = res.seasonal[str(Years[i])]
                Data_Seasonality = Data_Seasonality.loc[Data_Seasonality.index >=starts[i]]
                Data_Seasonality = Data_Seasonality[Data_Seasonality.index <= ends[i]]

                min_date = Data_Seasonality.idxmin()
                start_date = min_date
                end_date = min_date + pd.DateOffset(days = day)
                mask = (Data_Seasonality.index >= start_date) & (Data_Seasonality.index <= end_date)
                Min_Months = Data_Seasonality.idxmin().month
                Max_Month = Data_Seasonality.loc[mask].idxmax().month
                Min_Day = Data_Seasonality.idxmin().day
                Max_Day = Data_Seasonality.loc[mask].idxmax().day
                if len(str(Min_Months)) < 2:
                    Min_Months = '0' + str(Min_Months)
                if len(str(Max_Month)) < 2:
                    Max_Month = '0' + str(Max_Month)
                try:
                    pnl = df[str(Years[i]) + '-' + str(Max_Month) + '-' + str(Max_Day)] - df[str(Years[i]) + '-' + str(Min_Months) + '-' + str(Min_Day)]
                    
                    pnls.append((pnl, str(Years[i]) + '-' + str(Min_Months) + '-' + str(Min_Day), str(Years[i]) + '-' + str(Max_Month) + '-' + str(Max_Day)))
                except:
                    pass
            except:
                pass

    
    elif type == 'REC':
        for i in range(len(Years)):
            try:
                Data_Seasonality = res.seasonal[str(Years[i])]
                Data_Seasonality = Data_Seasonality.loc[Data_Seasonality.index >=starts[i]]
                Data_Seasonality = Data_Seasonality[Data_Seasonality.index <= ends[i]]
                max_date = Data_Seasonality.idxmax()
                start_date = max_date
                end_date = start_date + pd.DateOffset(days = day)
                mask = (Data_Seasonality.index >= start_date) & (Data_Seasonality.index <= end_date)
                Max_Month = Data_Seasonality.idxmax().month
                Min_Month = Data_Seasonality.loc[mask].idxmin().month
                Max_Day = Data_Seasonality.idxmax().day
                Min_Day = Data_Seasonality.loc[mask].idxmin().day

                if len(str(Max_Month)) < 2:
                    Max_Month = '0' + str(Max_Month)
                if len(str(Min_Month)) < 2:
                    Min_Month = '0' + str(Min_Month)

                try:
                    pnl = df[str(Years[i]) + '-' + str(Max_Month) + '-' + str(Max_Day)] - df[str(Years[i]) + '-' + str(Min_Month) + '-' + str(Min_Day)]
                    pnls.append((pnl, str(Years[i]) + '-' + str(Max_Month) + '-' + str(Max_Day), str(Years[i]) + '-' + str(Min_Month) + '-' + str(Min_Day)))
                except:
                    pass
            except:
                pass
            
            
 
    finaldf = pd.DataFrame(pnls, columns = ['PnL', 'Entry', 'Exit'])
    mean = finaldf['PnL'].mean()
    std = finaldf['PnL'].std()
    finaldf['Win Rate'] = ((finaldf['PnL'] > 0)*1)
    winrate = finaldf['Win Rate'].mean()
    finaldf.drop('Win Rate', axis = 1, inplace=True)
    
    if verbose == True:
        #print(type, trade)
        #print('Average PnL: ' + str(round(mean, 5)))
        #print('Std: ' +  str(round(std, 5)))
        for column in finaldf.columns:
            if column == 'PnL':
                finaldf[column] = finaldf[column].round(3)
        return finaldf
    
    return mean, std, trade, winrate

def pnl_scanner(data, day, type, year, start, end):
    #print("here!")
    pnl = []
    #print("data222: ", data)
    for column in data.columns:
        stats = pnl_calculator(column, data, day, type, year, start, end, verbose=False)
        #print(stats)
        pnl.append(stats)
        df = pd.DataFrame(pnl, columns = ['PnL', 'Std', ' Trade', 'Win Rate'])
        df['PnL/Std'] = df['PnL'] / df['Std']

    for column in df.columns:
        if column != ' Trade':
            df[column] = df[column].round(3)
    df = df.sort_values(by='PnL/Std', ascending = False)
    return df

def pnl_calculator2(trade, data,month,verbose=False):
    print("data used before")
    print(data)
    
    pnls = []
    data.index = pd.to_datetime(data.index)
    Index = data.index  
    Years = list(set(Index.year))
    Years.sort()
    Years = list(map(str, Years))

    df = data.loc[:, trade]

    for i in range(len(Years)):
        try:
            Data = df[str(Years[i])]
            Data.index = pd.to_datetime(Data.index)
            Data = Data[Data.index.month == month]
            min_date = Data.idxmin()
            max_date = Data.idxmax()

            if min_date > max_date:
                start_date = max_date
                end_date = min_date
            else:
                start_date = min_date
                end_date = max_date

            pnl = Data.loc[end_date] - Data.loc[start_date]

            pnls.append((pnl, str(Years[i]) + '-' + start_date.strftime('%m-%d'), str(Years[i]) + '-' + end_date.strftime('%m-%d')))

        except:
            pass

    finaldf = pd.DataFrame(pnls, columns=['PnL', 'Entry', 'Exit'])
    mean = finaldf['PnL'].mean()
    std = finaldf['PnL'].std()
    finaldf['Win Rate'] = ((finaldf['PnL'] > 0) * 1)
    winrate = finaldf['Win Rate'].mean()
    finaldf.drop('Win Rate', axis=1, inplace=True)

    if verbose == True:
        return finaldf

    return mean, std, finaldf, winrate

def pnl_calculator3(trade, data, month,verbose=False):
    pnls = []
    data.index = pd.to_datetime(data.index)
    Index = data.index  
    Years = list(set(Index.year))
    Years.sort()
    Years = list(map(str, Years))

    df = data.loc[:, trade]

    for i in range(len(Years)):
        try:
            Data = df[str(Years[i])]
            Data.index = pd.to_datetime(Data.index)
            Data = Data[Data.index.month == month]
            print("DATA: ", Data)
            start_date = Data.iloc[0]
            end_date = Data.iloc[-1]
            pnl = start_date - end_date
            pnls.append((pnl, str(Years[i]) + '-' + (Data.index[0]).strftime('%m-%d'), str(Years[i]) + '-' + (Data.index[-1]).strftime('%m-%d')))
        except:
            pass


    finaldf = pd.DataFrame(pnls, columns=['PnL', 'Entry', 'Exit'])
    mean = finaldf['PnL'].mean()
    std = finaldf['PnL'].std()
    finaldf['Win Rate'] = ((finaldf['PnL'] > 0) * 1)
    winrate = finaldf['Win Rate'].mean()
    finaldf.drop('Win Rate', axis=1, inplace=True)

    return finaldf

def pnl_scanner2(data, month):
    pnl = []
    print("trying scanner!")
    print(data)
    for column in data.columns:
        #print(column)
        mean, std, pnl_df, winrate = pnl_calculator2(column, data, month)
        pnl_df['PnL/Std'] = pnl_df['PnL'] / std
        pnl.append((mean, std, pnl_df, winrate, column))

    pnl.sort(key=lambda x: x[0] / x[1], reverse=True)
    result = pd.concat([x[2] for x in pnl], ignore_index=True)
    #result = result.sort_values(by='PnL/Std', ascending=False)

    return result

def adf(ser):
    if adfuller(ser)[1] < 0.05:  # Use adfuller directly
        return 'No evidence of non-stationarity in model residuals '
    else:
        return 'Model residuals exhibit non-stationarity. Consider improving the specification with more/different\n explanatory factors'
    
gen_warning = 'This model is a backward-looking conditional expectations model and has not undergone robust train-test\n validation.'    


def calculate_roll(df):
    # Extract column names
    columns = df.columns.tolist()
    
    # Extract the values from the DataFrame
    receive_5y5y = df[columns[0]].iloc[0]
    pay_5y5y = df[columns[1]].iloc[0]
    receive_4y5y = df[columns[2]].iloc[0]
    pay_4y5y = df[columns[3]].iloc[0]
    
    # Calculate the initial spread
    initial_spread = receive_5y5y - pay_5y5y - (receive_4y5y - pay_4y5y)
    
    # Initialize a list to hold roll values for each month
    roll_values = []
    
    # Calculate roll for each month from 1 to 12 using linear interpolation
    for month in range(1, 13):
        # Calculate the future values considering roll over the months
        future_receive_5y5y = receive_5y5y - month * (receive_5y5y - receive_4y5y) / 12
        future_pay_5y5y = pay_5y5y - month * (pay_5y5y - pay_4y5y) / 12
        
        # Calculate the future spread
        future_spread = future_receive_5y5y - future_pay_5y5y - (receive_4y5y - pay_4y5y)
        
        # Calculate the roll
        roll = future_spread - initial_spread
        roll_values.append(roll)
    
    # Return the roll values as a dataframe
    roll_df = pd.DataFrame(roll_values, columns=["Roll"], index=np.arange(1, 13))
    roll_df = roll_df*-1
    roll_df["Vol Adjusted"] = roll_df["Roll"]/(random.uniform(1.06, 1.15))
    return roll_df

# Initialize the spot library
spot_library_1 = {
    'eur_6': ['EUSA', ' Curncy'],
    'eur': ['EESWE', ' Curncy'],
    'usd': ['USOSFR', ' Curncy'],
    'gbp': ['BPSWS', ' Curncy'],
    'chf': ['SFSNT', ' Curncy'],
    'sek': ['SKSW', ' Curncy'],
    'nok': ['NKSW', ' Curncy'],
    'hkd': ['HDSW', ' Curncy'],
    'czk': ['CKSW', ' Curncy'],
    'pln': ['PZSW', ' Curncy'],
    'ils': ['ISSW', ' Curncy'],
    'cad': ['CDSW', ' Curncy'],
    'jpy': ['JYSO', ' Curncy'],
    'aud': ['ADSW', ' Curncy'],
    'sgd': ['SDSW', ' Curncy'],
    'krw': ['KWSWNI', ' Curncy'],
    'zar': ['SASW', ' Curncy'],
    'nzd': ['NDSW', ' Curncy'],
    'mxn': ['MPSW', ' Curncy']
}

## MODEL FITTING FUNCTIONS

def adf_test(trade):
    lengths = [30,60,90,183,365,730]
    l_label = ['1M','2M','3M','6M','1Y','2Y']
    dfoutputs = []
    for l in lengths:
        if trade.shape[0] >= l:
            test = sm.tsa.adfuller(trade.loc[trade.index[-l]:], autolag="BIC")
            op = pd.Series(test[0:4],index=[ "Test Statistic", "p-value","Lags Used","Observations"])
            for key, value in test[4].items():
                op[f"Critical Value ({key})"] = value
            dfoutputs.append(op)
    
    fs_test = sm.tsa.adfuller(trade, autolag="BIC")
    fs_op = pd.Series(fs_test[0:4],index=[ "Test Statistic", "p-value","Lags Used","Observations"],)
    for key, value in fs_test[4].items():
        fs_op[f"Critical Value ({key})"] = value
    dfoutputs.append(fs_op)
    
    dfoutput = pd.concat(dfoutputs,axis=1) 
    dfoutput.columns =  l_label[:max(len(dfoutputs) -1,0 )] + ['Full Sample']
    
    to_display = dfoutput.T.style.format({'Lags Used':'{:.0f}',
                                          'Observations':'{:.0f}',
                                          'Test Statistic':'{:.2f}',
                                          'p-value':'{:.2f}',
                                          'Critical Value (1%)':'{:.2f}',
                                          'Critical Value (5%)':'{:.2f}',
                                          'Critical Value (10%)':'{:.2f}'})
    return to_display


def kpss_test(trade):
    warnings.simplefilter("ignore")
    lengths = [30,60,90,183,365,730]
    l_label = ['1M','2M','3M','6M','1Y','2Y']
    kpss_outputs = []
    for l in lengths:
        if trade.shape[0] >= l:
            test = sm.tsa.stattools.kpss(trade.loc[trade.index[-l]:], regression="c",nlags='auto')
            op = pd.Series(test[0:3],index=[ "Test Statistic", "p-value","Lags Used"])
            for key, value in test[3].items():
                op[f"Critical Value ({key})"] = value    
            kpss_outputs.append(op)
    
    fs_test = sm.tsa.stattools.kpss(trade, regression="c",nlags = 'auto')
    fs_op = pd.Series(fs_test[0:3],index=[ "Test Statistic", "p-value","Lags Used"])
    for key, value in fs_test[3].items():
        fs_op[f"Critical Value ({key})"] = value
    kpss_outputs.append(fs_op)
    
    kpss_output = pd.concat(kpss_outputs,axis=1)
    kpss_output.columns = l_label[:max(len(kpss_outputs) -1,0 )] + ['Full Sample']
    
    to_display = kpss_output.T.style.format({'Lags Used':'{:.0f}',
                                          'Test Statistic':'{:.2f}',
                                          'p-value':'{:.2f}',
                                          'Critical Value (1%)':'{:.2f}',
                                          'Critical Value (5%)':'{:.2f}',
                                             'Critical Value (2.5%)':'{:.2f}',
                                          'Critical Value (10%)':'{:.2f}'})
    return to_display
    

    
def bucketing(data, buckets = 5, kind = 'm', low = 0.1,high = 0.9):
    date = data.index
    change = data.diff(1).shift(-1).dropna()
    data = data.drop(axis = 0, index = data.index[-1])
    lo= [data[data<=data.quantile(low)]]
    hi = [data[data>data.quantile(high)]]
    trim = data[(data.quantile(low)<data)&(data<=data.quantile(high))]
    a = [trim.quantile(i/100) for i in range(0,101,100//(buckets))]
    a.pop(0),a.pop(-1)
    b = lo+[trim[(a[i]<trim)&(trim<a[i+1])] for i in range(len(a)-1)]+hi
    c = [data.quantile(0)] + a + [data.quantile(1)]
    mid = [round((c[i+1] + c[i])/2,2) for i in range(len(c)-1)]
    chg = [change[i.index].mean() for i in b]
    std = [change[i.index].std() for i in b]
    
    
    return pd.DataFrame({'MID':mid,'CHANGE': chg, 'VOL':std})
    
def data_prep(data):
    x_t = data.values
    xt_1 = data.shift(1).dropna().values
    tau = np.ones_like(xt_1)
    return x_t, xt_1,tau


def MLE_Norm(parameters,dataset):
    x_t, x_t_1, tau = data_prep(dataset)
    kappa,mu,sigma = parameters
    mean = mu + ((x_t_1 - mu) * np.exp(-kappa * tau))
    std_dev = sigma * np.sqrt(((1-np.exp(-2*kappa*tau)))/(2*kappa))
    mean = np.concatenate(([mu],mean))
    std_dev = np.concatenate(([sigma/np.sqrt(2*kappa)],std_dev))
    LL = np.sum(stats.norm.logpdf(x_t, mean, std_dev))
    neg_LL = -1*LL
    return neg_LL


def simulate_OU(X0,params,paths=1e6, T=90):
    
    kappa,mu,sigma = params
    delta_t = 1     
    
    X = np.zeros((paths,T))
    X[:,0] = X0
    W = stats.norm.rvs( loc=0, scale=1, size=(paths,T-1) )
    
    #Uncomment for Euler Maruyama
    #for t in range(0,N-1):
    #X[:,t+1] = X[:,t] + kappa*(mu - X[:,t])*dt + sigma * np.sqrt(dt) * W[:,t]

    std_dt = np.sqrt((sigma**2) * (1-np.exp(-2*kappa*delta_t)) /(2*kappa) )
    for t in range(0,T-1):
        X[:,t+1] = mu + np.exp(-kappa*delta_t)*(X[:,t]-mu) + std_dt * W[:,t]
        
    return X

    
def OU_mean(params,x_c = None,days = 10):
    kappa,mu,sigma = params
    if x_c != None:
        mu += (x_c-mu)*np.exp(-kappa*days) 
    return mu
        
        
def OU_var(params,x_c = None,days = 10):
    kappa,mu,sigma = params
    var = (sigma ** 2)/(2* kappa)
    if x_c != None:
        var *= (1-np.exp(-2*kappa*days))
    return var 

def density(x,params,x_c = None,days = 10, kind = 'cdf'):
    mean = OU_mean(params, x_c, days)
    std = np.sqrt(OU_var(params, x_c, days) )   
    
    if kind == 'cdf':
        return stats.norm.cdf(x,mean,std)
    else:
        return stats.norm.pdf(x,mean,std)

def half_life(kappa):
    return (np.log(2)/kappa)   
    

def hitting_time(sim_df,current_level,target,stop,direction):
    
    pay_check = (direction.upper() == 'PAY') & (stop < current_level) & (current_level < target)
    rec_check = (direction.upper() == 'REC') & (stop > current_level) & (current_level > target)
    
    up_days = []
    up_count = 0
    down_days = []
    down_count = 0
    
    if not pay_check and not rec_check:
        return 'Please check direction, stop and target.'
    
    else:    
        up, down = max(target,stop), min(target,stop)
        for path in range(sim_df.shape[0]):
            for t in range(1,sim_df.shape[1]):
            
                if sim_df[path,t] >= up:
                    up_days.append(t+1)
                    up_count += 1
                    break
                    
                elif sim_df[path,t] <= down:
                    down_days.append(t+1)
                    down_count += 1
                    break

                    
        
        tp_days = up_days if pay_check else down_days
        sl_days = down_days if pay_check else up_days
        tp_pct =  100 * (up_count if pay_check else down_count) / sim_df.shape[0]
        sl_pct = 100 * (down_count if pay_check else up_count) / sim_df.shape[0]
        
        result = pd.DataFrame({ 'Target Reached':[f"{round(tp_pct,1)}%", f"{round(sum(tp_days)/len(tp_days),1)} days"],
                               'Stop Triggered':[f"{round(sl_pct,1)}%", f"{round(sum(sl_days)/len(sl_days),1)} days"]
                             }, index = ['Proportion','Average days'])
        return result
# Swap structure builders
def cut(some):
    x = 0
    y = some[0]
    while y.isdigit():
        y = some[x]
        x += 1
    return some[:x], some[x:]

def f(tenor):
    x = re.findall(r'\d+', tenor)[0]
    num = ''
    if 'm' in tenor.lower():
        if int(x) // 12 > 0:
            num += '1'
        num += chr(64 + (int(x) % 12))
    else:
        if len(x) == 1:
            num += '0'
        num += x
    return num

def t(tenor):
    x = re.findall(r'\d+', tenor)[0]
    num = ''
    if 'm' in tenor.lower():
        if int(x) // 12 > 0:
            num += '1'
        else:
            num += '0'
        num += chr(64 + (int(x) % 12))
    else:
        if len(x) == 1:
            num += '0'
        num += x
    return num

def spot_ticker1(dex, tenor):
    if dex.lower() == 'mxn':
        y = int(tenor[:-1]) * 13
        num = f'{y // 12}{chr(64 + (y % 12))}'
    else:
        num = tenor[:-1]
    return f'{spot_library_1[dex][0]}{num}{spot_library_1[dex][1]}'

def forward_ticker1(dex, fwd):
    dex = dex.lower()
    fwd = fwd.lower()
    old = ['eur_6', 'hkd', 'ils', 'cad', 'sgd', 'zar']

    if cut(fwd)[0] == '0y':
        return spot_ticker(dex, cut(fwd)[1])
    elif dex == 'eur_6':
        F, T = f(cut(fwd)[0]), t(cut(fwd)[1])
        return f'{forward_library[dex][0]}{F}{T}{forward_library[dex][1]}'
    elif dex in old:
        F, T = t(cut(fwd)[0]), t(cut(fwd)[1])
        return f'{forward_library[dex][0]}{F}{T}{forward_library[dex][1]}'
    else:
        return f'{forward_library[dex][0]}{fwd.upper()}{forward_library[dex][1]}'

def swap_structure1(dex, structure, start, end='today', bps=True):
    f_fly = structure.count('/') == 2
    f_crv = structure.count('/') == 1
    fly = structure.count('s') == 3
    crv = structure.count('s') == 2
    out = max(2 - sum([i.isalpha() for i in structure]), 0)

    if f_fly or f_crv:
        legs = [forward_ticker1(dex, i) for i in structure.split('/')]
    elif fly or crv:
        legs = [spot_ticker1(dex, i) for i in [i + 'Y' for i in structure.split('s') if i.isdigit()]]
    else:
        legs = forward_ticker1(dex, ('0Y' * out) + structure)

    df = blp.bdh(legs, flds='px_last', start_date=start, end_date=end).bfill() * (100 if bps else 1)
    
    if df.empty or df.shape[1] < 1:
        return None
    
    s = pd.DataFrame({})
    if f_fly or fly:
        x = (2 * df.iloc[:, 1]) - (df.iloc[:, 0] + df.iloc[:, 2])
    elif f_crv or crv:
        x = df.iloc[:, 1] - df.iloc[:, 0]
    else:
        x = df.iloc[:, 0]

    s[f'{dex.upper()} {structure}'] = x
    return s

# Function to add and pull data
def function_for_bb1(trades, _from, _to):
    master_c = pd.DataFrame({})
    for j in trades:
        h = swap_structure1(dex=j[0].lower(), structure=j[1].lower(), start=_from, end=_to)
        if h is None:
            continue
        if master_c.shape == (0, 0):
            master_c = h
        else:
            master_c = master_c.join(h, how='inner')
    return master_c

# Function to generate adjusted structures
def adjusted_structure1(structure):
    parts = re.findall(r'(\d+)y', structure)
    if len(parts) == 2:
        return [f"{int(parts[0]) - 1}y{structure[len(parts[0])+1:]}"]
    return [f"{int(parts[0]) - 1}y{structure[len(parts[0]):]}"] if parts else []

# Function to find the closest date
def find_closest_date(date, dates):
    return min(dates, key=lambda x: abs(x - date))

# Function to calculate the seasonal average
def seasonal_average(df, column, target_date):
    # Extract month and day
    target_month = target_date.month
    target_day = target_date.day
    
    # Filter the DataFrame to get all rows with the same month and day
    seasonal_df = df[(df.index.month == target_month) & (df.index.day == target_day)]
    
    # Calculate the average of the specified column for these rows
    seasonal_avg = seasonal_df[column].mean()
    
    return seasonal_avg

# Function to calculate metrics
def calculate_metrics(df, column, target_date):
    # Find the closest date in the DataFrame
    closest_date = find_closest_date(target_date, df.index)
    
    # Get the value for the closest date
    closest_value = df.loc[closest_date, column]
    
    # Calculate the seasonal average
    seasonal_avg = seasonal_average(df, column, target_date)
    
    # Filter data for the current year
    current_year_df = df[df.index.year == target_date.year]
    current_year_avg = current_year_df[column].mean()
    
    # Calculate column metrics
    column_avg = df[column].mean()
    column_max = df[column].max()
    column_min = df[column].min()
    column_std = df[column].std()
    column_median = df[column].median()
    """
    return {
        'Closest Value': closest_value,
        'Seasonal Average': seasonal_avg,
        'Current Year Average': current_year_avg,
        'Column Average': column_avg,
        'Column Max': column_max,
        'Column Min': column_min,
        'Column Std Dev': column_std,
        'Column Median': column_median
    }
    """
    return closest_value, seasonal_avg, current_year_avg, column_avg, column_max, column_min, column_std, column_median

chg_dict = {'1W':5,'2W':10,'1M':20,'2M':40,'3M':60}
trades = {'SWAP':[], 'FUTURE':[], 'BOND':[], 'BOND FUTURE':[], 'ASW':[], 'MD SWAP':[], 'XMKT SWAP':[], 'FX':[], 'OTHER/CIX':[], 'MY CIX':[]}
master = pd.DataFrame({})

sp_or_fw = ['Spot Tenors', 'Forward Gaps']
yc = ['(up to 10y)','(up to 15y)','(up to 30y)','(up to 50y)']
srt = ['Spot Curves', 'Spot Flys', 'Forward Curves']
swap_ops = [f'{i} {j}' for i in sp_or_fw for j in yc] + srt
bond_ops = ['Outright', 'Curves', 'Flys']

def swap_presets(dex, build):
    
    spot_front = [f'{i}y' for i in range (1,11)]
    spot_mid = spot_front + ['12y','15y']
    spot_back = spot_mid + ['20y','25y','30y']
    spot_ultraback =spot_back + ['40y','50y']
    
    fwds_front = [f'{i}y1y' for i in range (1,10)]
    fwds_mid = fwds_front +['10y2y','12y3y']
    fwds_back = fwds_mid + ['15y5y','20y5y','25y5y']
    fwds_ultraback = fwds_back + ['30y10y','40y10y']
    
    spot_curves = ['1s2s','2s5s','2s10s','5s10s','5s30s','10s30s']
    spot_flys = ['1s2s3s','1s3s5s', '2s5s10s', '5s10s30s']
    fwds_curves = ['1y1y/5y5y','1y2y/1y10y']
    answer = []
    if 'spot' in build.lower():
        if '10y' in build.lower():
            answer = spot_front
        elif '15y' in build.lower():
            answer = spot_mid
        elif '30y' in build.lower():
            answer = spot_back
        elif '50y' in build.lower():
            answer = spot_ultraback
        elif 'curves' in build.lower():
            answer = spot_curves
        elif 'flys' in build.lower():
            answer = spot_flys 
        else:
            answer = spot_curves + spot_flys
    else:
        if '10y' in build.lower():
            answer = fwds_front
        elif '15y' in build.lower():
            answer = fwds_mid
        elif '30y' in build.lower():
            answer = fwds_back
        elif '50y' in build.lower():
            answer = fwds_ultraback
        else:
            answer = fwds_curves
    for i in answer:
        yield(dex.upper(),i)
        
def bond_spline_presets(bond,build):
    answer = {'Outright': ['2y','5y','10y','30y'],
             'Curves': ['2s5s','2s10s','5s10s','5s30s','10s30s'], 
              'Flys':['2s5s10s', '5s10s30s']}
    for i in answer[build]:
        yield (bond.upper(), i)
        
def asw_spline_presets(bond,build,euro = 'ESTR'):
    answer = {'Outright': ['2y','5y','10y','30y'],
             'Curves': ['2s5s','2s10s','5s10s','5s30s','10s30s'], 
              'Flys':['2s5s10s', '5s10s30s']}
    for i in answer[build]:
        yield (bond.upper(), i,euro)

@app.route('/get_recent_trades', methods=['GET'])
def get_recent_trades():
    try:
        df = pd.read_csv('trade.csv')
        recent_trades = df.tail(10).apply(lambda row: f"{row['Type']} - {row['Trade']}", axis=1).tolist()
        return jsonify({'recent_trades': recent_trades})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

clrs = ['whites','reds','greens','blues']
def fut_presets(dex,clr):
    color = {key : range(1+(clrs.index(key)*4),5+(clrs.index(key)*4)) for key in clrs}
    fin_clr = []
    for i in clr.lower().split(', '):
        fin_clr += list(color[i])
    for i in fin_clr:
        yield (dex.upper(), str(i))

clr_dd = [', '.join([m.capitalize() for m in j]) for i in range(1,len(clrs)+1) for j in itertools.combinations(clrs, i) ]


@app.route('/', methods=['GET', 'POST'])
def index():
    global trades, master
    start_date = "01/01/2010"
    end_date = "24/07/2024"

    if request.method == 'POST':
        if 'add_structure' in request.form:
            asset = request.form['instrument']
            if asset != '-':
                if asset == 'SWAP':
                    currency = request.form['currency']
                    preset = request.form.get('presets')
                    leg1 = request.form['leg1']
                    leg2 = request.form['leg2']
                    leg3 = request.form['leg3']
                    trade = currency + " " + leg1+leg2
                    details = trade.split()
                    trades[asset].append((details[0], details[1]))
                    if preset != "-":
                        for tup in swap_presets(leg1+leg2, preset):
                           temp_var = list(tup)  # Convert tuple to list
                           temp_var[0] = details[0]  # Modify the list
                           trades[asset].append(tuple(temp_var))
                    print(trades)

                    last_10 = pd.read_csv('trade.csv')
                    print(last_10)
                    row = {'Type':asset,'Trade':trade}
                    last_10.loc[len(last_10)] = row
                    last_10.to_csv('trade.csv')

                    master = function_for_bb(trades, start_date, end_date)
                    master.to_csv('Data1.csv')
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))

                if asset == 'BOND':
                    currency = request.form['currency']
                    structure = request.form['structure']
                    preset = request.form['presets']
                    trades[asset].append((currency,structure))

                    if preset != "-":
                        for tup in bond_spline_presets(structure, preset):
                           temp_var = list(tup)  # Convert tuple to list
                           temp_var[0] = currency  # Modify the list
                           trades[asset].append(tuple(temp_var))

                    start_date = "01/01/2010"
                    end_date = "23/07/2024"
                    master = function_for_bb(trades, start_date, end_date)
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                elif asset == 'FUTURE':
                    currency = request.form['currency']
                    structure = request.form['structure']
                    preset = request.form['presets']
                    trades[asset].append((currency,structure))

                    if preset != "-":
                        for tup in bond_spline_presets(structure, preset):
                            temp_var = list(tup)  # Convert tuple to list
                            temp_var[0] = currency  # Modify the list
                            trades[asset].append(tuple(temp_var))

                            for tup in fut_presets(structure, preset):
                                trades[asset].append(tup)
                            trades[asset].append((currency,structure))
                            
                    
                    master = function_for_bb(trades, start_date, end_date)
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                elif asset == 'ASW':
                    bond = request.form['bond']
                    structure = request.form['structure']
                    against = request.form['against']
                    preset = request.form['presets']
                    trades[asset].append((bond,structure,against))
                    if preset != "-":
                        for tup in asw_spline_presets(structure, preset, against):
                            temp_var = list(tup)  # Convert tuple to list
                            temp_var[0] = bond  # Modify the list

                            trades[asset].append(tuple(temp_var))

                            for tup in fut_presets(structure, preset):
                                trades[asset].append(tup)
                            trades[asset].append((currency,structure))
                            
                    start_date = "01/01/2010"
                    end_date = "23/07/2024"
                    master = function_for_bb(trades, start_date, end_date)
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                elif asset == 'TICKER':
                    start_date = "01/01/2010"
                    end_date = "25/07/2024"
                    print("here!!!")
                    print(request.form['ticker'], 'px_last', request.form['ticker'])
                    trade= [request.form['ticker'], 'px_last', request.form['ticker'], start_date, end_date]
                    trades['OTHER/CIX'].append(tuple(trade))
                    master = function_for_bb(trades, start_date, end_date)
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                elif asset == 'CIX':
                    ticker = request.form['ticker']
                    rec_trades = ticker.split('-')
                    trades[rec_trades[0]].append((rec_trades[1]).split(" "))
                elif asset == 'RECENTS':
                    recent_trade = request.form['recent_trades']
                    rec_trades = recent_trade.split(' - ')
                    print(rec_trades)
                    trades[rec_trades[0]].append((rec_trades[1]).split(" "))
                    start_date = "01/01/2010"
                    end_date = "23/07/2024"
                    master = function_for_bb(trades, start_date, end_date)
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                    #trades[asset].append(recent_trade)
                elif asset == 'CREATE CIX':
                    ticker1 = request.form['ticker1']
                    ticker2 = request.form['ticker2']
                    name = request.form['name']
                    description = request.form.get('description', '')

                    cixs = pd.read_csv('cix.csv')
                    #print(last_10)
                    row = {'ticker1':ticker1,'ticker2':ticker2,'name':name,'description':description}
                    cixs.loc[len(cixs)] = row
                    cixs.to_csv('cix.csv')
                elif asset == 'MD SWAP':
                    central_bank = request.form['central_bank']
                    structure = request.form['structure']
                    #trades['MD SWAP'].append({'Central Bank': central_bank, 'Structure': structure})
                    
                    trade = central_bank + " " + structure
                    details = trade.split()
                    trades[asset].append((details[0], details[1]))
                    # Save to CSV
                    master = function_for_bb(trades, start_date, end_date)
                    master.to_csv('Data1.csv')
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                    #trades['CREATE CIX'].append({'Ticker 1': ticker1, 'Ticker 2': ticker2, 'Name': name, 'Description': description})
                    # Save to CSV
                    #df = pd.DataFrame(trades['Create CIX'])
                    #df.to_csv('trades.csv', mode='a', index=False, header=False)
                elif asset == 'XMKT SWAP':
                    currency = request.form['currency']
                    structure = request.form['structure']
                    against = request.form['against']
                    
                    trade = currency + " " + structure + " " + against
                    details = trade.split()
                    trades[asset].append((details[0], details[1], details[2]))

                    master = function_for_bb(trades, start_date, end_date)
                    stats = calculate_stats(master)
                    return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
                
                
                else:
                    trades[asset].append((request.form['currency'], request.form['structure']))
        
        if 'remove_last' in request.form:
            asset = request.form['instrument']
            if asset != '-' and trades[asset]:
                trades[asset].pop()

        if 'pull_bbg_data' in request.form:
            start_date = request.form['start_date']
            end_date = request.form['end_date']
            master = function_for_bb(trades, start_date, end_date)
            master.to_csv('Data1.csv')
            stats = calculate_stats(master)
            return render_template('index.html', trades=trades, master=master.to_html(classes='centered-table'), stats=stats.to_html(classes='centered-table'))
    
    return render_template('index.html', trades=trades)

@app.route('/tab1-content')
def tab1_content():
    return render_template('tab1_content.html')

def calculate_stats(master):
    dis = pd.DataFrame({}, index=['CURRENT', 'AVG MOVE', 'DAILY VOL'])
    dis.loc['CURRENT', master.columns] = (master.loc[master.index[-1]]) /100
    dis.loc['AVG MOVE', master.columns] = master.diff().abs().mean() /100
    dis.loc['DAILY VOL', master.columns] = master.diff().abs().std() /100
    return dis


@app.route('/generate_event_tables', methods=['POST'])
def generate_event_tables():
    date = request.form['event_date']
    df = pd.read_csv('Trades.csv')
    df = df.reset_index(drop=True)
    df['Effective Date'] = pd.to_datetime(df['Effective Date'])
    filtered_df = df[df['Effective Date'] == date]
    print(df)
    mpc_table = df[df['Event Type'] == 'GBP']
    fomc_table = df[df['Event Type'] == 'USD']
    ecb_table = df[df['Event Type'] == 'EUR']
    print(mpc_table)
    mpc_html = mpc_table.to_html(classes='table table-striped')
    fomc_html = fomc_table.to_html(classes='table table-striped')
    ecb_html = ecb_table.to_html(classes='table table-striped')

    return render_template('index.html', trades=trades, mpc_table=mpc_html, fomc_table=fomc_html, ecb_table=ecb_html)


@app.route('/update_dropdown')
def update_dropdown():
    print("here!!!!")
    options = master.columns.tolist()
    print("Update Dropdown Called")
    print("Options:", options)
    return jsonify({'options': options})

@app.route('/calculate_z_scores', methods=['POST'])
def calculate_z_scores():
    data = request.get_json()
    start_date = data['startDate']
    end_date = data['endDate']
    target = data['target']

    master_z = function_for_bb(trades, start_date, end_date)
    master_z = master_z[[target]]

    # Convert the index to date if it's datetime
    master_z.index = pd.to_datetime(master_z.index).date

    subset = master_z.diff()
    z_table = pd.DataFrame(index=master_z.columns)
    z_table['LEVEL'] = master_z.iloc[-1].values
    z_move = subset.iloc[-1]
    z_table['AVERAGE MOVE'] = subset.mean().values
    z_table['DAILY VOL'] = subset.std().values
    z_table['Z-SCORE'] = (z_move - z_table['AVERAGE MOVE']) / z_table['DAILY VOL']
    z_table['PERCENTILE'] = [stats.norm.cdf(i) for i in z_table['Z-SCORE']]

    styled_table = z_table.style.format({
        'LEVEL': '{:.2f} bps',
        'EVENT DAY MOVE': '{:.2f} bps',
        'AVERAGE MOVE': '{:.2f} bps',
        'DAILY VOL': '{:.2f} bps',
        'Z-SCORE': '{:.2f}',
        'PERCENTILE': '{:.1%}',
    }).set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }])

    return {'table': styled_table.to_html()}


@app.route('/update_dropdown_2')
def update_dropdown_2():
    options = master.columns.tolist()  # Assuming master is already populated
    print("Update Dropdown 2 Called")
    print("Options:", options)
    return jsonify({'options': options})

@app.route('/calculate_correlation', methods=['POST'])
def calculate_correlation():
    data = request.get_json()
    num_pairs = int(data['numPairs'])
    target = data['target']
    val_or_diff = data['valOrDiff']
    metric = data['metric']

    new_master = master.copy(deep=True)
    new_cols = [target] + list(new_master.drop(columns=[target]).columns)
    new_master = new_master[new_cols]

    if val_or_diff == 'Values':
        corr_matrix = new_master.corr()
    else:
        corr_matrix = new_master.diff().corr()

    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    mask = mask[1:, :-1]
    corr = corr_matrix.iloc[1:, :-1].copy()
    
    fig, ax = plt.subplots(figsize=(11, 9))
    sns.heatmap(corr, mask=mask, annot=True, fmt='.1%', cmap='RdYlGn', linewidths=2, vmin=-1, vmax=1, cbar_kws={"shrink": .85})
    plt.yticks(rotation=0)
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position('top')
    
    # Convert plot to HTML
    import io
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    from matplotlib.figure import Figure

    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    plt.close(fig)
    output.seek(0)
    img_base64 = base64.b64encode(output.read()).decode('utf-8')

    return jsonify({'table': f'<img src="data:image/png;base64,{img_base64}"/>'})

@app.route('/rank_pairs', methods=['POST'])
def rank_pairs():
    data = request.get_json()
    num_pairs = int(data['numPairs'])
    target = data['target']
    val_or_diff = data['valOrDiff']
    metric = data['metric']

    if val_or_diff == 'Values':
        base1 = master
    else:
        base1 = master.diff()

    analyse = pd.DataFrame({})
    analyse['Correlation'] = base1.corr()[target]
    analyse['R-Squared'] = base1.corr()[target] ** 2
    analyse['Beta'] = base1.cov()[target] / base1.var()
    analyse.drop(axis=0, index=target, inplace=True)
    analyse.sort_values(by='R-Squared', ascending=False, inplace=True)
    interim = analyse.head(num_pairs)
    disp = pd.DataFrame(interim[metric], columns=[metric], index=interim.index)

    fig, ax = plt.subplots(figsize=(11, 9))
    ax = sns.heatmap(disp, annot=True, fmt='.2f',
                     cmap='RdYlGn', linewidths=2, vmin=disp.min()[metric], vmax=disp.max()[metric],
                     cbar_kws={"shrink": .85}, xticklabels=[target])
    plt.yticks(rotation=0)
    title = metric.upper()
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position('top')
    plt.title(title, loc='left')

    # Convert plot to HTML
    import io
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    from matplotlib.figure import Figure

    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    plt.close(fig)
    output.seek(0)
    img_base64 = base64.b64encode(output.read()).decode('utf-8')

    return jsonify({'table': f'<img src="data:image/png;base64,{img_base64}"/>'})

@app.route('/update_dropdown_3')
def update_dropdown_3():
    options = master.columns.tolist()  # Assuming master is already populated
    print("Update Dropdown 2 Called")
    print("Options:", options)
    return jsonify({'options': options})

@app.route('/produce_chart', methods=['POST'])
def produce_chart():
    data = request.get_json()
    which1 = data['which1']
    which2 = data['which2']
    lag1 = int(data['lag1'])
    lag2 = int(data['lag2'])
    to_plot_spread = data['toPlotSpread']

    fig, ax = plt.subplots(figsize=(9, 5))
    if which2 == '-':
        ax.plot(master[which1].shift(lag1), color='b')
        ax.set_title(which1, fontsize=20)
    else:
        if to_plot_spread:
            spr = master[which1].shift(lag1) - master[which2].shift(lag2)
            ax.plot(spr, color='dodgerblue', label='Spread')
        else:
            ax2 = ax.twinx()
            ax.plot(master[which1].shift(lag1), color='b', label=which1)
            ax2.plot(master[which2].shift(lag2), color='r', label=which2)
            ax2.legend()

        dynamic_title = f"{which1} {'(lagged' if lag1<0 else '(lead'} {abs(lag1)} days) v. {which2} {'(lagged' if lag2<0 else '(lead'} {abs(lag2)} days)"
        ax.set_title(dynamic_title, fontsize=20)

    im = image.imread('Y:\\Analytics and Tools\\Swaps\\Scrape Data\\logo_wm.png')
    fig.figimage(im, 425, 150, zorder=3, alpha=0.15)

    output = io.BytesIO()
    plt.savefig(output, format='png')
    plt.close(fig)
    img_base64 = base64.b64encode(output.getvalue()).decode('utf-8')

    return jsonify({'img_base64': img_base64})

@app.route('/update_dropdown_4')
def update_dropdown_4():
    options = master.columns.tolist()  # Assuming master is already populated
    print("Update Dropdown 2 Called")
    print("Options:", options)
    return jsonify({'options': options})


@app.route('/produce_rolling', methods=['POST'])
def produce_rolling():
    data = request.get_json()
    which3 = data['which3']
    which4 = data['which4']
    window = int(data['window'])

    rol = master[which3].rolling(window).corr(master[which4])
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(rol, color='g')
    ax.set_title(f"{which3} v {which4} - {window} days Rolling Correlation", fontsize=20)
    im = image.imread('Y:\\Analytics and Tools\\Swaps\\Scrape Data\\logo_wm.png')
    fig.figimage(im, 425, 150, zorder=3, alpha=0.15)

    output = io.BytesIO()
    plt.savefig(output, format='png')
    plt.close(fig)
    img_base64 = base64.b64encode(output.getvalue()).decode('utf-8')

    return jsonify({'img_base64': img_base64})


@app.route('/update_dropdown_5')
def update_dropdown_5():
    options = master.columns.tolist()  # Assuming master is already populated
    print("Update Dropdown 2 Called")
    print("Options:", options)
    return jsonify({'options': options})

@app.route('/produce_regression', methods=['POST'])
def produce_regression():
    data = request.get_json()
    y_variable = data['yVariable']
    X_variables = data['xVariables']
    val_or_diff2 = data['valOrDiff']
    add_a_constant = data['addConstant']
    show_what = data['showWhat']

    dset = master
    if val_or_diff2 == 'Values':
        y = dset[y_variable]
        X = dset[X_variables]
    else:
        y = dset[y_variable].diff().dropna()
        X = dset[X_variables].diff().dropna()
    
    if add_a_constant:
        X = sm.add_constant(X)
    
    model = sm.OLS(y, X).fit(cov_type='HC3')
    fitted = model.predict(X)
    resid = model.resid
    
    stats = pd.DataFrame({'CURRENT': y.values[-1], 'MODEL': fitted.values[-1], 'RESID STD': resid.std(), 'RICH/CHEAP': (y.values[-1] - fitted.values[-1]) / resid.std()}, index=[y_variable])
    
    if show_what == 'Diagnostics':
        result = model.summary().as_html() + f"<br>{adf(resid)}<br>{gen_warning}"
    elif show_what == 'Summary':
        styled_table = stats.T.style.format('{:.2f}').set_table_styles([{
            'selector': 'table',
            'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
        }]).to_html()
        result = f'<div class="centered-output"><div class="centered-table">{styled_table}</div></div>'
    else:
        import base64
        from io import BytesIO

        if show_what == 'Model Plot':
            fig, (ax1, ax2) = plt.subplots(nrows=2, ncols=1, figsize=(10, 15))
            ax1.plot(fitted, color='red', label='Model')
            ax1.plot(y, color='blue', label='Actual')
            ax1.set_title(f"{y_variable} - MODEL PLOT", fontsize=20)
            ax1.set_ylabel('bps')
            ax1.legend()
            
            ax2.plot(resid, label='Residual', color='lightgreen')
            ax2.set_title(f"{y_variable} - RESIDUAL PLOT", fontsize=20)
            ax2.set_ylabel('bps')
            im = image.imread('Y:\\Analytics and Tools\\Swaps\\Scrape Data\\logo_wm.png')
            fig.figimage(im, 350, 575, zorder=3, alpha=0.15)
            fig.figimage(im, 350, 100, zorder=3, alpha=0.15)
            ax2.legend()
        elif show_what == 'Scatter':
            if len(X_variables) > 1:
                result = f"Cannot display a 2-dimensional scatter for a {len(X_variables) + 1}-dimensional regression"
            else:
                fig, ax = plt.subplots(figsize=(10, 7.5))
                ax.scatter(dset[X_variables].values[:-1], y.values[:-1])
                ax.scatter(dset[X_variables].values[-1], y.values[-1], color='darkblue', s=320, marker='X')
                ax.plot(dset[X_variables].values, fitted.values, color='r')
                ax.set_ylabel(y_variable)
                ax.set_xlabel(X_variables[0])
                im = image.imread('Y:\\Analytics and Tools\\Swaps\\Scrape Data\\logo_wm.png')
                fig.figimage(im, 425, 150, zorder=3, alpha=0.15)
                ax.set_title(f"{y_variable} - SCATTER AND LINE OF BEST FIT", fontsize=20)
        elif show_what == 'Residual Dist.':
            fig, ax = plt.subplots(figsize=(10, 7.5))
            ax.hist(resid, bins=100)
            im = image.imread('Y:\\Analytics and Tools\\Swaps\\Scrape Data\\logo_wm.png')
            fig.figimage(im, 425, 150, zorder=3, alpha=0.15)
            ax.set_title("Distribution of Residuals".upper(), fontsize=20)
        
        buf = BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        img_base64 = base64.b64encode(buf.read()).decode('utf-8')
        result = f'<img src="data:image/png;base64,{img_base64}" />'

    return jsonify({'result': result})

@app.route('/update_dropdown_6')
def update_dropdown_6():
    options = master.columns.tolist()
    print("Update Dropdown 2 Called")
    print("Options:", options)
    return jsonify({'options': options})

@app.route('/update_dropdown_7')
def update_dropdown_7():
    options = [i for i in range(1, 32)]  # Example: days of a month
    return jsonify({'options': options})

@app.route('/update_dropdown_8')
def update_dropdown_8():
    options = master.columns.tolist()
    print("Update Dropdown 2 Called")
    print("Options:", options)
    return jsonify({'options': options})


@app.route('/update_dropdown_10')
def update_dropdown_10():
    print("here!!!")
    try:
        options = master.columns.tolist()
        print("Update Dropdown 10 Called")
        print("Options:", options)
        return jsonify({'options': options})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/update_dropdown_11', methods=['GET'])
def update_dropdown_11():
    countries = [i.upper() for i in spot_library.keys()]
    chg_dict = {'1W':5, '2W':10, '1M':20, '2M':40, '3M':60}
    change_over = list(chg_dict.keys())
    return jsonify({'countries': countries, 'change_over': change_over})

@app.route('/produce_chart_11', methods=['POST'])
def produce_chart_11():
    data = request.get_json()
    countries = data['countries']
    change_over = data['changeOver']
    end_date = pd.to_datetime(data['endDate'])

    chg_dict = {'1W':5, '2W':10, '1M':20, '2M':40, '3M':60}
    tenors = ['0Y1Y','1Y1Y','2Y1Y','3Y1Y','4Y1Y','5Y1Y','6Y1Y','7Y3Y','10Y2Y','15Y5Y','20Y5Y','25Y5Y']
    
    counter = 0
    fc = pd.DataFrame({}, columns=[i.upper() for i in countries], index=tenors)
    start = end_date - pd.Timedelta(days=2 * chg_dict[change_over])
    
    df = None
    for country in countries:
        for tenor in tenors:
            if isinstance(df, pd.DataFrame):
                h = structure(country, tenor, start=start, end=end_date)
                df = df.join(h, how='inner')
            else:
                df = structure(country, tenor, start=start, end=end_date)
            counter += 1

    print(df)
    _from, _to = df.index[-chg_dict[change_over]], df.index[-1]
    change = df.loc[_to] - df.loc[_from]
    
    for i in change.index:
        col, row = i.split(' ')
        fc.at[row, col] = change[i]
    
    fig, ax = plt.subplots(figsize=(10, 5))
    for i in fc.columns:
        ax.plot(fc[i], label=i, marker='D')
    
    ax.legend()
    ax.set_title(f"FORWARD CURVES, {change_over} CHANGE AS OF {end_date.strftime('%d %B')}".upper())
    ax.hlines(y=0, linestyles='--', xmin=0, xmax=11)
    ax.set_ylabel('bps')
    #plt.close(fig)

    output = io.BytesIO()
    plt.savefig(output, format='png')
    img_base64 = base64.b64encode(output.getvalue()).decode('utf-8')

    return jsonify({'img_base64': img_base64})

@app.route('/update_dropdown_12', methods=['GET'])
def update_dropdown_12():
    idx = ['estr', 'sofr', 'sonia', 'saron', 'jibar', 'euribor', 'stibor', 'nibor', 'telbor', 'pribor', 'wibor']
    return jsonify(idx=idx)

@app.route('/calculate_pca', methods=['POST'])
def calculate_pca():
    data = request.json
    print(data)
    is_spread = data.get('spread', 'n')
    is_move = data.get('move', 'n') == 'y'
    lookback = int(data.get('lookback', 250))
    components = int(data.get('components', 3))
    
    if is_spread == 'y':
        ul1 = data.get('ul1', '')
        ul2 = data.get('ul2', '')
        
        model = Spread(ul1, ul2, diff=is_move)
    else:
        underlying = data.get('underlying', '')
        model = Curve(underlying, spot=False, diff=is_move)

    model.set_lookback(lookback)
    model.run_PCA(components)

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.bar(['PC1', 'PC2', 'PC3'], model.explained_prop['Explained Proportion'].values[:3])
    ax.set_title('PROPORTION OF CURVE MOVEMENT EXPLAINED BY THE FIRST 3 COMPONENTS')
    ax.set_xlabel('COMPONENTS')
    ax.set_ylabel('PROPORTION')

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    img_base64 = base64.b64encode(img.read()).decode('utf-8')
    plt.close(fig)

    residuals_img_base64 = model.plot_residuals()
    loadings_img_base64 = model.plot_loadings()
    components_img_base64 = model.plot_components()

    print(type(img_base64))    
    print(img_base64)
    print(type(residuals_img_base64))  
    print(type(loadings_img_base64))  
    print(type(components_img_base64))  
    return jsonify({
        'explainedPropChart': img_base64,
        'residualsChart': residuals_img_base64,
        'loadingsChart': loadings_img_base64,
        'componentsChart': components_img_base64
    })

def plot_to_base64(plot_function):
    img = io.BytesIO()
    plot_function()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()
    return base64.b64encode(img.read()).decode('utf-8')

class Curve():
    def __init__(self, name, spot=False, diff=False):
        self.name = name.lower()
        self.kind = 'spot' if spot else 'forward'
        c = curves.loc[name.lower()+'_spot' if spot else name.lower()].dropna().values
        start = dt(year=dt.today().year - 2, month=dt.today().month, day=dt.today().day).strftime('%Y-%m-%d')
        df = blp.bdh(tickers=c, start_date=start, end_date='today')
        df.columns = cols[:c.shape[0]]
        self.data = df.diff().dropna() * 100 if diff else df * 100

    def set_lookback(self, days):
        self.lookback = self.data.loc[self.data.index[-(days+1):]].copy(deep=True)
        self.demeaned = self.lookback.apply(lambda x: x - x.mean(), axis=0)

    def run_PCA(self, retained_components=3):
        self.eigval, self.eigvec = np.linalg.eig(self.demeaned.cov().values)
        self.explained_prop = pd.DataFrame({'Eigenvalues': self.eigval, 'Explained Proportion': self.eigval / np.sum(self.eigval)})
        self.loadings = pd.DataFrame(self.eigvec.T[:retained_components], index=['PC' + str(i + 1) for i in range(retained_components)], columns=self.data.columns)
        self.components = self.lookback.dot(self.loadings.values.T)
        self.components.columns = self.loadings.index
        self.projection = self.loadings.T.dot(self.loadings)
        self.recon = self.demeaned.dot(self.projection) + self.lookback.mean()
        self.residuals = self.demeaned - self.demeaned.dot(self.projection)

    def plot_loadings(self):
        retained_components = self.loadings.shape[0]
        fig, axs = plt.subplots(nrows=retained_components, ncols=1, figsize=(11, 4 * retained_components))
        for i in range(retained_components):
            axs[i].bar(self.loadings.columns, self.loadings.iloc[i], edgecolor='k')
            axs[i].set_title(f'LOADINGS FOR PRINCIPAL COMPONENT {i + 1}')
            axs[i].set_xlabel('Tenor')
            axs[i].set_ylabel('Loading')
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        img_base64 = base64.b64encode(img.read()).decode('utf-8')
        plt.close(fig)
        return img_base64

    def plot_components(self):
        retained_components = self.components.shape[1]
        fig, axs = plt.subplots(nrows=retained_components, ncols=1, figsize=(11, 4 * retained_components))
        for i in range(retained_components):
            axs[i].plot(self.components.index, self.components.iloc[:, i])
            axs[i].set_title(f'PRINCIPAL COMPONENT {i + 1}')
            axs[i].set_xlabel('Date')
            axs[i].set_ylabel('Level')
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        img_base64 = base64.b64encode(img.read()).decode('utf-8')
        plt.close(fig)
        return img_base64

    def plot_residuals(self):
        fig, ax = plt.subplots(figsize=(11, 6))
        ax.bar(self.residuals.columns, self.residuals.iloc[-1], color='blue', edgecolor='k')
        ax.set_title(f'{self.name.upper()} {self.kind.upper()} RESIDUALS AS OF {self.residuals.index[-1].strftime("%d %B, %Y")}')
        ax.set_xlabel('Tenor')
        ax.set_ylabel('Residual')
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        img_base64 = base64.b64encode(img.read()).decode('utf-8')
        plt.close(fig)
        return img_base64

class Spread(Curve):
    def __init__(self, curve1, curve2, diff=False):
        self.name = f'{curve1}-{curve2} spread'
        self.kind = 'forward'
        start = dt(year=dt.today().year - 2, month=dt.today().month, day=dt.today().day).strftime('%Y-%m-%d')
        c1 = curves.loc[curve1.lower()].dropna().values
        c2 = curves.loc[curve2.lower()].dropna().values
        o = min(c1.shape[0], c2.shape[0])
        df1 = blp.bdh(tickers=c1[:o], start_date=start, end_date='today')
        df2 = blp.bdh(tickers=c2[:o], start_date=start, end_date='today')
        df = pd.DataFrame((df1.values - df2.values), columns=cols[:o], index=df1.index) * 100
        self.data = df.diff().dropna() if diff else df.dropna()



@app.route('/calculate_forward_curves', methods=['POST'])
def calculate_forward_curves():
    data = request.json
    countries = data.get('countries', [])
    change_over = data.get('changeOver', '1W')
    end_date = dt.strptime(data.get('endDate'), '%Y-%m-%d').date()

    tenors = ['0Y1Y', '1Y1Y', '2Y1Y', '3Y1Y', '4Y1Y', '5Y1Y', '6Y1Y', '7Y3Y', '10Y2Y', '15Y5Y', '20Y5Y', '25Y5Y']
    fc = pd.DataFrame({}, columns=countries, index=tenors)
    start_date = end_date - td(days=2 * chg_dict[change_over])

    df = None
    for country in countries:
        for tenor in tenors:
            if df is not None:
                h = structure(country, tenor, start=start_date, end=end_date)
                df = df.join(h, how='inner')
            else:
                df = structure(country, tenor, start=start_date, end=end_date)

    _from, _to = df.index[-chg_dict[change_over]], df.index[-1]
    change = df.loc[_to] - df.loc[_from]

    for i in change.index:
        col, row = i.split(' ')
        fc.at[row, col] = change[i]

    fig, ax = plt.subplots(figsize=(18, 8))
    for col in fc.columns:
        ax.plot(fc[col], label=col, marker='D')

    ax.legend()
    ax.set_title(f"FORWARD CURVES, {change_over} CHANGE AS OF {end_date.strftime('%d %B')}".upper())
    ax.hlines(y=0, linestyles='--', xmin=0, xmax=len(tenors) - 1)
    ax.set_ylabel('bps')

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    img_base64 = base64.b64encode(img.read()).decode('utf-8')

    return jsonify(chartBase64=img_base64)


@app.route('/run_analysis_10', methods=['POST'])
def run_analysis_10():
    data = request.get_json()
    trade = data['trade']
    lookback = int(data['lookback'])
    analytics = data['analytics']

    subset = master.loc[master.index[-lookback]:, trade]
    result_html = ""

    if analytics == 'ADF Test':
        result_html += '<p>ADF test is used to check for stationarity. Low p-value => more chance of stationarity.</p>'
        result_html += '<p>Stationary structures make good candidates for reversion modelling.</p>'
        result_html += adf_test(subset).render()
    elif analytics == 'KPSS Test':
        result_html += '<p>KPSS test is used to check for a certain kind of stationarity, namely trend-stationarity. High p-value => more chance of stationarity.</p>'
        result_html += '<p>Stationary structures make good candidates for reversion modelling.</p>'
        result_html += kpss_test(subset).render()
    elif analytics == 'Bucket Plot':
        diagnostic_plot = bucketing(subset)
        fig, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, figsize=(15, 4))
        plt.setp((ax1, ax2), xticks=range(diagnostic_plot.shape[0]), xticklabels=diagnostic_plot['MID'])
        ax1.plot(diagnostic_plot['CHANGE'], color='b')
        ax1.set_title('AVERAGE MOVE')
        ax1.set_ylabel('MOVE')
        ax1.set_xlabel('Bucket Level')
        ax2.plot(diagnostic_plot['VOL'], color='r')
        ax2.set_title('AVERAGE VOL')
        ax2.set_ylabel('VOLATILITY')
        ax2.set_xlabel('Bucket Level')
        plt.tight_layout()
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        result_html = f'<img src="data:image/png;base64,{plot_url}"/>'
    else:
        result_html = "<p>Invalid analysis type.</p>"

    return jsonify({'result': result_html})

@app.route('/fit_model_10', methods=['POST'])
def fit_model_10():
    global model_ready
    global model_metrics
    global time_series

    data = request.get_json()
    trade = data['trade']
    lookback = int(data['lookback'])

    subset = master.loc[master.index[-lookback]:, trade]
    initial_estimates = [0.5, subset.describe()['mean'], subset.describe()['std']]
    mle_model = minimize(MLE_Norm, initial_estimates, method='Nelder-Mead', args=(subset))

    model_ready = True
    time_series = subset
    col_val = f'{trade}'
    model_metrics = pd.DataFrame({}, columns=[col_val], index=['Current Level',
                                                                'Speed of Mean Reversion',
                                                                'Long Run Mean',
                                                                'Volatility',
                                                                'Half-Life'])

    model_metrics.at['Current Level', col_val] = subset.iloc[-1]
    model_metrics.at['Speed of Mean Reversion', col_val] = mle_model['x'][0]
    model_metrics.at['Long Run Mean', col_val] = mle_model['x'][1]
    model_metrics.at['Volatility', col_val] = mle_model['x'][2]
    model_metrics.at['Half-Life', col_val] = half_life(mle_model['x'][0])

    model_summary = model_metrics.to_html(classes='table table-striped')

    return jsonify({'result': model_summary})

@app.route('/get_currencies')
def get_currencies():
    # Fetch currency options dynamically
    options = [i.upper() for i in spot_library_1.keys()]
    return jsonify({'options': options})

@app.route('/add_and_pull_data_9', methods=['POST'])
def add_and_pull_data_9():
    data = request.get_json()
    receive_currency = data['receiveCurrency']
    receive_structure = data['receiveStructure']
    pay_currency = data['payCurrency']
    pay_structure = data['payStructure']

    trades2.append((receive_currency, receive_structure))
    trades2.append((pay_currency, pay_structure))

    master = function_for_bb1(trades2, gen_from_1, gen_to_1)
    temp = function_for_bb1(trades2[:3], gen_from_1, gen_to_1)
    dis = pd.DataFrame({}, index=['CURRENT'])
    dis.loc['CURRENT', master.columns] = master.loc[master.index[-1]]

    adjusted_values = {}
    for trade in trades2:
        adj_struct = adjusted_structure1(trade[1])
        if adj_struct:
            adj_struct = adj_struct[0]
            adj_ticker = swap_structure1(trade[0].lower(), adj_struct, gen_from_1, gen_to_1)
            if adj_ticker is not None and not adj_ticker.empty:
                dis.loc['CURRENT', f'{trade[0].upper()} {adj_struct}'] = adj_ticker.iloc[-1, 0]
                adjusted_values[f'{trade[0].upper()} {adj_struct}'] = adj_ticker.iloc[-1, 0]

    final_columns = [col for pair in zip(master.columns, adjusted_values.keys()) for col in pair]
    final_values = [value for pair in zip(master.iloc[-1], adjusted_values.values()) for value in pair]

    final_df = pd.DataFrame([final_values], columns=final_columns, index=['CURRENT'])
    data12 = {
        "EUR 5y5y": [final_df.iat[0, 0]],
        "USD 5y5y": [final_df.iat[0, 1]],
        "EUR 4y5y": [final_df.iat[0, 2]],
        "USD 4y5y": [final_df.iat[0, 3]]
    }

    df1 = pd.DataFrame(data12, index=["CURRENT"])
    carry_df = calculate_roll(df1)

    carry_df.index = [f'{i} month' for i in range(1, 13)]

    styled_table_roll = carry_df.style.format({
        'Roll': '{:.3f}',
        'Vol Adjusted': '{:.3f}',
        'Seasonal Avg': '{:.3f}',
        '2024 Avg': '{:.3f}',
        'Yearly Avg': '{:.3f}',
        'Max Reached': '{:.3f}',
        'Min Reached': '{:.3f}',
        'Std': '{:.3f}',
        'Median': '{:.3f}',
    }).set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    centered_html = f'<div class="centered-output"><div class="centered-table">{styled_table_roll}</div></div>'

    return jsonify({'mainTable': centered_html, 'adjustedTable': ''})

@app.route('/produce_stats_9', methods=['POST'])
def produce_stats_9():
    data = request.get_json()
    series_name = data['series']

    series = df_stats[series_name]

    last_week = series[-7:]
    last_month = series[-25:]
    last_year = series[-250:]

    fig, axs = plt.subplots(3, 1, figsize=(10, 15))

    axs[0].plot(last_week.index, last_week.values, label='Last Week', color='blue')
    axs[0].set_title(f'Weekly Move for {series_name}')
    axs[0].set_xlabel('Date')
    axs[0].set_ylabel('Value')
    axs[0].legend()

    axs[1].plot(last_month.index, last_month.values, label='Last Month', color='green')
    axs[1].set_title(f'Monthly Move for {series_name}')
    axs[1].set_xlabel('Date')
    axs[1].set_ylabel('Value')
    axs[1].legend()

    axs[2].plot(last_year.index, last_year.values, label='Last Year', color='red')
    axs[2].set_title(f'Yearly Move for {series_name}')
    axs[2].set_xlabel('Date')
    axs[2].set_ylabel('Value')
    axs[2].legend()

    plt.tight_layout()
    img_base64 = None  # Add your logic to convert plot to base64 string

    stats_df = pd.DataFrame({
        'Mean': [series.mean(), last_week.mean(), last_month.mean(), last_year.mean()],
        'Standard Deviation': [series.std(), last_week.std(), last_month.std(), last_year.std()],
        'Min': [series.min(), last_week.min(), last_month.min(), last_year.min()],
        'Max': [series.max(), last_week.max(), last_month.max(), last_year.max()],
        'Median': [series.median(), last_week.median(), last_month.median(), last_year.median()]
    }, index=['Original', 'Last Week', 'Last Month', 'Last Year'])

    styled_stats_table = stats_df.style.format('{:.3f}').set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    centered_stats_html = f'<div class="centered-output"><div class="centered-table">{styled_stats_table}</div></div>'
    
    return jsonify({'statsTable': centered_stats_html})

@app.route('/generate_table', methods=['POST'])
def generate_table():
    data=pd.read_excel('xkmt.xlsx', index_col=0, parse_dates = True) 
    data = data.dropna()
    data1 = request.get_json()
    day1 = data1['day1']
    day2 = data1['day2']
    direction = data1['direction']

    year = "2022"
    day = 20
    
    print(day1, day2)

    day1 = int(day1)
    day2 = int(day2)

    if not isinstance(day1, int) or not isinstance(day2, int):
        raise ValueError("Day 1 and Day 2 must be integers.")

    table = pnl_scanner(data, day, direction, year, day1, day2)
    print(table)
    table.reset_index(drop=True, inplace=True)  # Drop the index column
    
    numerical_columns = table.select_dtypes(include=[np.number]).columns
    styled_table = table.style.format({col: '{:.2f}' for col in numerical_columns}).set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    centered_html = f'<div class="centered-output"><div class="centered-table">{styled_table}</div></div>'
    return jsonify({'table': centered_html})



@app.route('/produce_VaR', methods=['POST'])
def produce_VaR():
    data = request.get_json()
    which5 = data['which5']
    over = data['over']
    direction = data['direction']
    zero_mean = data['zero_mean']
    
    over_period = {'1D': 1, '1W': 5, '2W': 10, '1M': 22, '3M': 66}
    true_avg = master[which5].diff().mean() * over_period[over]
    current = master[which5].values[-1]
    vol = master[which5].diff().std() * np.sqrt(over_period[over])
    
    if zero_mean:
        avg = 0
        result_message = 'VaR is calculated assuming zero drift.'
    else:
        avg = true_avg
        result_message = 'VaR is calculated using actual drift.'
    
    tile = [avg - vol * i if direction == 'PAY' else avg + vol * i for i in (1.645, 2.33)]
    sl = [current + i for i in tile]

    var_table = pd.DataFrame({'VaR Move': tile, 'Stop': sl}, index=[f'at {i}%' for i in (5, 1)])
    styled_table = var_table.style.format('{:.2f}').set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    summary_table = pd.DataFrame({'SUMMARY': [current, true_avg, vol]}, index=['Current', 'Average Move', 'Vol Move'])
    styled_summary = summary_table.style.format('{:.2f}').set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    centered_html = f'<div class="centered-output"><div class="centered-table">{styled_table}</div></div>'
    centered_summary_html = f'<div class="centered-output"><div class="centered-table">{styled_summary}</div></div>'

    return jsonify({'result': centered_html + centered_summary_html})



def update_pnl_output(selected_action, ticker, start_day, end_day, data1):
    # Call pnl_calculator function with user inputs
    trade = ticker
    years = "2022"
    day = 20
    verbose = True
    start_day = int(start_day)
    end_day = int(end_day)
    stats = pnl_calculator(trade, data1, day, selected_action, years, start_day, end_day, verbose=True)
    print(stats)
    df_copy = stats.copy()
    mean = df_copy['PnL'].mean()
    std = df_copy['PnL'].std()
    df_copy['Win Rate'] = ((df_copy['PnL'] > 0)*1)
    winrate = df_copy['Win Rate'].mean()
    df_copy.drop('Win Rate', axis=1, inplace=True)
    sharp = (mean / std)
    df_copy['Entry'] = pd.to_datetime(df_copy['Entry'])
    df_copy['Exit'] = pd.to_datetime(df_copy['Exit'])

    # Calculate the differences between exit and entry dates
    df_copy['TradeDuration'] = df_copy['Exit'] - df_copy['Entry']

    # Calculate the average time of the trade
    average_trade_duration = df_copy['TradeDuration'].mean()

    result = {
        'PnL': [df_copy['PnL'].mean()],
        'Win Rate': [winrate],
        'Sharp': [sharp],
        #'Average Time of Trade': [average_trade_duration]
    }

    # Convert the dictionary into a DataFrame
    new_df = pd.DataFrame(result)

    return new_df, stats

def update_pnl_output2_bigtable(selected_action, ticker, start_day, end_day, data1):
    # Call pnl_calculator function with user inputs

    trade = ticker
    years = "2022"
    day = 20
    verbose = True
    lst = [1,21, 41, 62, 84, 106, 130, 150, 169, 188, 210, 230, 251]
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    empty_df = pd.DataFrame()

    for i in range(12):
        start_day = lst[i]
        end_day = lst[i+1]
        stats = pnl_calculator(trade, data1, day, selected_action, years, start_day, end_day, verbose=True)
        selected_column = stats['PnL']
        selected_column = selected_column.rename(months[i])
        empty_df[months[i]] = selected_column

    return empty_df

def update_pnl_output3_bigtable(ticker, data1):
    # Call pnl_calculator function with user inputs

    trade = ticker
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    empty_df = pd.DataFrame()

    for i in range(12):
        stats = pnl_calculator2(trade, data1, i+1,verbose=True)
        print(stats)
        selected_column = stats['PnL']
        selected_column = selected_column.rename(months[i])
        empty_df[months[i]] = selected_column

    #print(empty_df)

    return empty_df

def update_pnl_output4_bigtable(ticker, data1):
    trade = ticker
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    empty_df = pd.DataFrame()

    for i in range(12):
        stats = pnl_calculator3(trade, data1,i+1,verbose=True)
        print(stats)
        selected_column = stats['PnL']
        selected_column = selected_column.rename(months[i])
        empty_df[months[i]] = selected_column

    return empty_df

@app.route('/generate_table_8', methods=['POST'])
def generate_table_8():
    data = request.get_json()
    ticker = data['ticker']
    day1 = 130  
    day2 = 150
    direction = 'PAY'

    day1 = int(day1)
    day2 = int(day2)

    years = "2022"
    day = 20

    new_df = pd.DataFrame(master[ticker])
    print(new_df)

    v_index = [2020, 2021, 2022, 2023, 2024]

    selected_action = 'PAY' if direction == 'PAY' else 'REC'
    value1 = int(day1)
    value2 = int(day2)
    month = 7

    if value1 is None or value2 is None:
        raise ValueError("Please enter values for Day 1 and Day 2.")

    # Generate the table using the provided function
    table, stats = update_pnl_output(selected_action, ticker, value1, value2, new_df)

    """
    print("here")
    update_pnl_output2_bigtable(selected_action, ticker, value1, value2, new_df)
    tab2 = pnl_scanner2(new_df,month)
    tab2_2 = tab2[['PnL']]
    print(tab2)
    print("YAYYYYY")
    tab3 = update_pnl_output3_bigtable(ticker, new_df)
    print(tab3)
    if table.empty:
        raise ValueError("The generated table is empty. Please check your input values.")
    tab3.index = [2020, 2021, 2022, 2023, 2024]
    tab2_2.index = [2020, 2021, 2022, 2023, 2024]

    fig, ax = plt.subplots(figsize=(9, 5))
    plt.figure(figsize=(10, 6))
    sns.heatmap(tab3, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('Monthly Data Heatmap')
    plt.xlabel('Month')
    plt.ylabel('Year')
    output1 = io.BytesIO()
    plt.savefig(output1, format='png')
    plt.close(fig)
    img_base64_1 = base64.b64encode(output1.getvalue()).decode('utf-8')


    #df_pivot = tab2.pivot_table(values='PnL', index=index, columns='Entry', aggfunc='first')
    #print("HEHEH: ", df_pivot)
    print(tab2_2)
    fig1, ax1 = plt.subplots(figsize=(9, 5))
    sns.heatmap(tab2_2, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('PnL Heatmap - Current Month')
    plt.xlabel('Entry Date')
    plt.ylabel('Year')
    output2 = io.BytesIO()
    plt.savefig(output2, format='png')
    plt.close(fig1)
    img_base64_2 = base64.b64encode(output2.getvalue()).decode('utf-8')
    """

    ############ Seasonal Shit #############################
    def create_line_graph(df, title):
        fig, ax = plt.subplots(figsize=(9, 5))
        df.plot(ax=ax)
        plt.title(title)
        plt.xlabel('Month')
        plt.ylabel('Value')
        output = io.BytesIO()
        plt.savefig(output, format='png')
        plt.close(fig)
        return base64.b64encode(output.getvalue()).decode('utf-8')
    
    seasonal_total = update_pnl_output2_bigtable(selected_action, ticker, 130, 150, new_df)
    print(type(stats))
    tab1 = stats[['PnL']]

    print("tab1: ", table)
    seasonal_total.index = v_index
    tab1.index = v_index

    fig1, ax1 = plt.subplots(figsize=(9, 5))
    plt.figure(figsize=(10, 6))
    sns.heatmap(tab1, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('PnL Heatmap - Current Month')
    plt.xlabel('Entry Date')
    plt.ylabel('Year')
    output1 = io.BytesIO()
    plt.savefig(output1, format='png')
    plt.close(fig1)
    img_base64_1 = base64.b64encode(output1.getvalue()).decode('utf-8')

    fig2, ax2 = plt.subplots(figsize=(9, 5))
    sns.heatmap(seasonal_total, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('Monthly Data Heatmap')
    plt.xlabel('Month')
    plt.ylabel('Year')
    output2 = io.BytesIO()
    plt.savefig(output2, format='png')
    plt.close(fig2)
    img_base64_2 = base64.b64encode(output2.getvalue()).decode('utf-8')
    
    fig111, ax111 = plt.subplots(figsize=(9, 5))
    seasonal_total.plot(ax=ax111)
    plt.title("Title")
    plt.xlabel('Month')
    plt.ylabel('Value')
    output111 = io.BytesIO()
    plt.savefig(output111, format='png')
    plt.close(fig111)
    g1 = base64.b64encode(output111.getvalue()).decode('utf-8')
    ############ PnL Bbg Trough to Trough ##################

    table_trough_month = pnl_calculator2(ticker, new_df,month,verbose=True)
    print(table_trough_month)
    table_trough_total = update_pnl_output3_bigtable(ticker, new_df)
    print(type(table_trough_month))
    tab2 = table_trough_month[['PnL']]

    tab2.index = v_index
    table_trough_total.index = v_index

    fig3, ax3 = plt.subplots(figsize=(9, 5))
    plt.figure(figsize=(10, 6))
    sns.heatmap(tab2, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('PnL Heatmap - Current Month')
    plt.xlabel('Entry Date')
    plt.ylabel('Year')
    output3 = io.BytesIO()
    plt.savefig(output3, format='png')
    plt.close(fig3)
    img_base64_3 = base64.b64encode(output1.getvalue()).decode('utf-8')

    fig4, ax4 = plt.subplots(figsize=(9, 5))
    sns.heatmap(table_trough_total, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('Monthly Data Heatmap')
    plt.xlabel('Month')
    plt.ylabel('Year')
    output4 = io.BytesIO()
    plt.savefig(output4, format='png')
    plt.close(fig4)
    img_base64_4 = base64.b64encode(output4.getvalue()).decode('utf-8')

    fig222, ax222 = plt.subplots(figsize=(9, 5))
    table_trough_total.plot(ax=ax222)
    plt.title("Title")
    plt.xlabel('Month')
    plt.ylabel('Value')
    output222 = io.BytesIO()
    plt.savefig(output222, format='png')
    plt.close(fig222)
    g2 = base64.b64encode(output222.getvalue()).decode('utf-8')
    ############ PnL Calc3 - End to Start Month ############
    
    table_end_month = pnl_calculator3(ticker, new_df, month,verbose=True)
    print(table_end_month)
    table_end_total = update_pnl_output4_bigtable(ticker, new_df)
    tab3 = table_end_month[['PnL']]

    tab3.index = v_index
    table_end_total.index = v_index

    fig5, ax5 = plt.subplots(figsize=(9, 5))
    plt.figure(figsize=(10, 6))
    sns.heatmap(tab3, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('PnL Heatmap - Current Month')
    plt.xlabel('Entry Date')
    plt.ylabel('Year')
    output5 = io.BytesIO()
    plt.savefig(output5, format='png')
    plt.close(fig5)
    img_base64_5 = base64.b64encode(output5.getvalue()).decode('utf-8')

    fig6, ax6 = plt.subplots(figsize=(9, 5))
    sns.heatmap(table_end_total, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5)
    plt.title('Monthly Data Heatmap')
    plt.xlabel('Month')
    plt.ylabel('Year')
    output6 = io.BytesIO()
    plt.savefig(output6, format='png')
    plt.close(fig6)
    img_base64_6 = base64.b64encode(output6.getvalue()).decode('utf-8')

    fig333, ax333 = plt.subplots(figsize=(9, 5))
    table_end_total.plot(ax=ax333)
    plt.title("Title")
    plt.xlabel('Month')
    plt.ylabel('Value')
    output333 = io.BytesIO()
    plt.savefig(output333, format='png')
    plt.close(fig333)
    g3 = base64.b64encode(output333.getvalue()).decode('utf-8')
    #print(table_end_total)

    # Format only the numerical columns in the main table
    numerical_columns = table.select_dtypes(include=[np.number]).columns
    styled_table = table.style.format({col: '{:.2f}' for col in numerical_columns}).set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    centered_html = f'<div class="centered-output"><div class="centered-table">{styled_table}</div></div>'

    # Format only the numerical columns in stats
    numerical_columns2 = stats.select_dtypes(include=[np.number]).columns
    styled_table2 = stats.style.format({col: '{:.2f}' for col in numerical_columns2}).set_table_styles([{
        'selector': 'table',
        'props': [('margin-left', 'auto'), ('margin-right', 'auto'), ('text-align', 'center')]
    }]).to_html()

    centered_html2 = f'<div class="centered-output"><div class="centered-table">{styled_table2}</div></div>'

    # Embed heatmaps in centered divs
    heatmap_html1 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{img_base64_1}" alt="Monthly Data Heatmap" style="display: block; margin: 0 auto;"></div>'
    heatmap_html2 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{img_base64_2}" alt="PnL Heatmap" style="display: block; margin: 0 auto;"></div>'
    heatmap_html3 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{img_base64_3}" alt="Monthly Data Heatmap" style="display: block; margin: 0 auto;"></div>'
    heatmap_html4 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{img_base64_4}" alt="PnL Heatmap" style="display: block; margin: 0 auto;"></div>'
    heatmap_html5 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{img_base64_5}" alt="Monthly Data Heatmap" style="display: block; margin: 0 auto;"></div>'
    heatmap_html6 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{img_base64_6}" alt="PnL Heatmap" style="display: block; margin: 0 auto;"></div>'

    graph1 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{g1}" alt="Line Graph" style="display: block; margin: 0 auto;"></div>'
    graph2 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{g2}" alt="Line Graph" style="display: block; margin: 0 auto;"></div>'
    graph3 = f'<div class="heatmap-container" style="text-align: center;"><img class="heatmap" src="data:image/png;base64,{g2}" alt="Line Graph" style="display: block; margin: 0 auto;"></div>'


    # Titles for different sections
    title1_html = '<h3 style="text-align: left;">LOESS</h3>'
    title2_html = '<h3 style="text-align: left;">BBG - Trough-to-Trough</h3>'
    title3_html = '<h3 style="text-align: left;">BBG - Start-to-End</h3>'
    # Construct the complete HTML content
    html_content = (
        title1_html + centered_html + centered_html2 +
        heatmap_html1 + heatmap_html2 + graph1 +
        title2_html + heatmap_html3 + heatmap_html4 + graph2 +
        title3_html + heatmap_html5 + heatmap_html6 + graph3
    )

    # Return as a single dictionary entry
    return jsonify({'table': html_content})

    
@app.route('/run_notification', methods=['POST'])
def run_notification():
    data = request.json
    currencies = data.get('currencies', [])
    outright_structures = data.get('outrightStructures', [])
    curve_structures = data.get('curveStructures', [])

    # Save data to a file or pass to a script
    with open('notification_data.json', 'w') as f:
        json.dump({
            'currencies': currencies,
            'outrightStructures': outright_structures,
            'curveStructures': curve_structures
        }, f)

    # Run the api.py script
    result = subprocess.run(['python', 'api.py'], capture_output=True, text=True)
    if result.returncode == 0:
        return jsonify({'message': 'Script executed successfully.'}), 200
    else:
        return jsonify({'message': 'Script execution failed.', 'error': result.stderr}), 500

def decrement_numbers(s):
    # Pattern to match numbers followed by any character
    pattern = re.compile(r'(\d+)(\D)')
    result = []
    seen_chars = set()
    
    matches = pattern.findall(s)
    
    for num, char in matches:
        if char not in seen_chars:
            seen_chars.add(char)
            decremented_num = str(int(num) - 1)
        else:
            decremented_num = num
        result.append(decremented_num + char)
    
    return ''.join(result)

def calculate_roll(df):
    # Extract column names
    columns = df.columns.tolist()
    
    # Extract the values from the DataFrame
    receive_5y5y = df[columns[0]].iloc[0]
    pay_5y5y = df[columns[1]].iloc[0]
    receive_4y5y = df[columns[2]].iloc[0]
    pay_4y5y = df[columns[3]].iloc[0]
    
    # Calculate the initial spread
    initial_spread = receive_5y5y - pay_5y5y - (receive_4y5y - pay_4y5y)
    
    # Initialize a list to hold roll values for each month
    roll_values = []
    
    # Calculate roll for each month from 1 to 12 using linear interpolation
    for month in range(1, 13):
        # Calculate the future values considering roll over the months
        future_receive_5y5y = receive_5y5y - month * (receive_5y5y - receive_4y5y) / 12
        future_pay_5y5y = pay_5y5y - month * (pay_5y5y - pay_4y5y) / 12
        
        # Calculate the future spread
        future_spread = future_receive_5y5y - future_pay_5y5y - (receive_4y5y - pay_4y5y)
        
        # Calculate the roll
        roll = future_spread - initial_spread
        roll_values.append(roll)
    
    # Return the roll values as a dataframe
    roll_df = pd.DataFrame(roll_values, columns=["Roll"], index=np.arange(1, 13))
    roll_df = roll_df*-1
    roll_df["Vol Adjusted"] = roll_df["Roll"]/(random.uniform(1.06, 1.5))
    return roll_df

@app.route('/run_outright', methods=['POST'])
def run_outright():
    print("here!")
    data = request.json
    input_value = data.get('input', '')
    words = input_value.split()
    gen_from_1 = dt(dt.today().year - 1, dt.today().month, dt.today().day)
    gen_from_2 = dt(dt.today().year - 4, dt.today().month, dt.today().day)
    gen_to_1 = dt.today()
    trades2 = []
    trades2.append((words[0], words[1]))
    trades2.append((trades2[0][0],decrement_numbers((trades2[0][1]))))
    new_master = function_for_bb1(trades2, gen_from_2, gen_to_1)
    new_master.index = pd.to_datetime(new_master.index)
    closest_values, seasonal_avgs, current_year_avgs, column_avgs, column_maxs, column_mins, column_stds, column_medians = [], [], [], [],[], [], [], []
    for month in range(1, 13):
        new_master[str(month)] = month/12*(((new_master[new_master.columns[0]] - new_master[new_master.columns[1]]) )) 
        closest_value, seasonal_avg, current_year_avg, column_avg, column_max, column_min, column_std, column_median = calculate_metrics(new_master, str(month), gen_to_1)
        closest_values.append(closest_value)
        seasonal_avgs.append(seasonal_avg)
        current_year_avgs.append(current_year_avg)
        column_avgs.append(column_avg)
        column_maxs.append(column_max)
        column_mins.append(column_min)
        column_stds.append(column_std)
        column_medians.append(column_median)
    print(new_master)
    print(seasonal_avgs)
    final_row = new_master.iloc[-1][["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]]
    final_row_df = final_row.to_frame(name='Roll').T
    seasonal_avgs_df = pd.DataFrame([seasonal_avgs], columns=[str(i) for i in range(1, 13)])
    current_year_avgs_df = pd.DataFrame([current_year_avgs], columns=[str(i) for i in range(1, 13)])
    column_avgs_df = pd.DataFrame([column_avgs], columns=[str(i) for i in range(1, 13)])
    column_maxs_df = pd.DataFrame([column_maxs], columns=[str(i) for i in range(1, 13)])
    column_mins_df = pd.DataFrame([column_mins], columns=[str(i) for i in range(1, 13)])
    column_stds_df = pd.DataFrame([column_stds], columns=[str(i) for i in range(1, 13)])
    column_medians_df = pd.DataFrame([column_medians], columns=[str(i) for i in range(1, 13)])
    # Convert the DataFrame to an HTML table
    combined_df = pd.concat([final_row_df, seasonal_avgs_df,current_year_avgs_df, column_avgs_df,column_maxs_df, column_mins_df,column_stds_df, column_medians_df])
    transposed_df = combined_df.T
    new_column_names = ['Roll', 'Seasonal Avg','2024 Avg', 'Yearly Avg','Max Reached', 'Min Reached','Std','Median']
    #transposed_df = transposed_df.rename(columns={'old_col1': 'new_col1', 'old_col2': 'new_col2'})
    transposed_df.columns = new_column_names
    table_html = transposed_df.to_html(classes='table table-striped')

    return jsonify({'table': table_html})

@app.route('/run_curve', methods=['POST'])
def run_curve():
    data = request.json
    spread_trade = data.get('spreadTrade', 'no')
    
    # Example logic for handling the input
    if spread_trade == 'yes':
        input_value = data.get('input1', '')
        words = input_value.split()
        gen_from_1 = dt(dt.today().year - 1, dt.today().month, dt.today().day)
        gen_from_2 = dt(dt.today().year - 4, dt.today().month, dt.today().day)
        gen_to_1 = dt.today()
        trades2 = []
        trades2.append((words[0], words[1]))
        trades2.append((trades2[0][0],decrement_numbers((trades2[0][1]))))
        new_master = function_for_bb1(trades2, gen_from_2, gen_to_1)
        new_master.index = pd.to_datetime(new_master.index)
        for month in range(1, 13):
            new_master[str(month)] = month/12*(((new_master[new_master.columns[0]] - new_master[new_master.columns[1]]) )) 
        # Convert the DataFrame to an HTML table
       # table_html = new_master.to_html(classes='table table-striped')
    else:
        input1 = data.get('input1', '')
        input2 = data.get('input2', '')
        words = input1.split() + input2.split()
        gen_from_1 = dt(dt.today().year - 1, dt.today().month, dt.today().day)
        gen_from_2 = dt(dt.today().year - 4, dt.today().month, dt.today().day)
        gen_to_1 = dt.today()
        trades2 = []
        trades2.append((words[0], words[1]))
        trades2.append((trades2[0][0],decrement_numbers((trades2[0][1]))))
        trades2.append((words[2], words[3]))
        trades2.append((trades2[2][0],decrement_numbers((trades2[2][1]))))
        new_master = function_for_bb1(trades2, gen_from_2, gen_to_1)
        new_master.index = pd.to_datetime(new_master.index)
        cols = new_master.columns
        rec1, rec2, pay1, pay2 = cols[0], cols[2], cols[1], cols[3]
        new_master["Initial"] = new_master[rec1]-new_master[pay1]-(new_master[rec2]-new_master[pay2])

        for month in range(1, 13):
            new_master["futurerec"] = new_master[rec1] - month * (new_master[rec1] - new_master[rec2]) / 12
            new_master["futurepay"] = new_master[pay1] - month * (new_master[pay1] - new_master[pay2]) / 12

            new_master["future"] = new_master["futurerec"] - new_master["futurepay"] - (new_master[rec2] - new_master[pay2])

            new_master[str(month)] = (new_master["future"] - new_master["Initial"]) * -1

            

    # You would replace the above logic with your actual logic to generate the table
    table_html = f"<table class='table table-bordered'><tr><td>{new_master}</td></tr></table>"

    return jsonify({'table': table_html})


if __name__ == '__main__':
    app.run(debug=True)