import re
import pandas as pd

dfr = pd.read_csv('cix.csv')
print(dfr)