import datetime
import requests
import pandas as pd
from zipfile import ZipFile
from io import BytesIO
import locale
from dateutil.relativedelta import relativedelta
from tkinter import Tk, Text, Scrollbar, RIGHT, Y, END
import threading
import time
import math
import warnings

warnings.simplefilter('ignore')

locale.setlocale(locale.LC_ALL, 'en_US')

base_url = r'https://kgc0418-tdw-data-0.s3.amazonaws.com/cftc/slices/CFTC_SLICE_RATES_{:%Y_%m_%d}_{}.zip'

names = [    "H23", "M23", "U23", "Z23",    "H24", "M24", "U24", "Z24",    "H25", "M25", "U25", "Z25",    "H26", "M26", "U26", "Z26",    "H27", "M27", "U27", "Z27",    "H28", "M28", "U28", "Z28",    "H29", "M29", "U29", "Z29",    "H30", "M30", "U30", "Z30",    "H31", "M31", "U31", "Z31",    "H32", "M32", "U32", "Z32",    "H33", "M33", "U33", "Z33",    "H34", "M34", "U34", "Z34",    "H35", "M35", "U35", "Z35",    "H36", "M36", "U36", "Z36",    "H37", "M37", "U37", "Z37",    "H38", "M38", "U38", "Z38",    "H39", "M39", "U39", "Z39",    "H40", "M40", "U40", "Z40",    "H41", "M41", "U41", "Z41",    "H42", "M42", "U42", "Z42",    "H43", "M43", "U43", "Z43",    "H44", "M44", "U44", "Z44",    "H45", "M45", "U45", "Z45",    "H46", "M46", "U46", "Z46",    "H47", "M47", "U47", "Z47",    "H48", "M48", "U48", "Z48",    "H49", "M49", "U49", "Z49",    "H50", "M50", "U50", "Z50",    "H51", "M51", "U51", "Z51",    "H52", "M52", "U52", "Z52"]
dates = [    "2023-03-15", "2023-06-21", "2023-09-20", "2023-12-20",    "2024-03-20", "2024-06-19", "2024-09-18", "2024-12-18",    "2025-03-19", "2025-06-18", "2025-09-17", "2025-12-17",    "2026-03-18", "2026-06-17", "2026-09-16", "2026-12-16",    "2027-03-17", "2027-06-16", "2027-09-15", "2027-12-15",    "2028-03-15", "2028-06-21", "2028-09-20", "2028-12-20",    "2029-03-21", "2029-06-20", "2029-09-19", "2029-12-19",    "2030-03-20", "2030-06-19", "2030-09-18", "2030-12-18",    "2031-03-19", "2031-06-18", "2031-09-17", "2031-12-17",    "2032-03-17", "2032-06-16", "2032-09-15", "2032-12-15",    "2033-03-16", "2033-06-15", "2033-09-21", "2033-12-21",    "2034-03-21", "2034-06-20", "2034-09-20", "2034-12-20",    "2035-03-21", "2035-06-20", "2035-09-19", "2035-12-19",    "2036-03-19", "2036-06-18", "2036-09-17", "2036-12-17",    "2037-03-18", "2037-06-17", "2037-09-16", "2037-12-16",    "2038-03-17", "2038-06-16", "2038-09-15", "2038-12-15",    "2039-03-16", "2039-06-15", "2039-09-21", "2039-12-21",    "2040-03-21", "2040-06-20", "2040-09-19", "2040-12-19",    "2041-03-20", "2041-06-19", "2041-09-18", "2041-12-18",    "2042-03-18", "2042-06-18", "2042-09-17", "2042-12-17",    "2043-03-17", "2043-06-17", "2043-09-16", "2043-12-16",    "2044-03-16", "2044-06-15", "2044-09-21", "2044-12-21",    "2045-03-21", "2045-06-20", "2045-09-19", "2045-12-19",    "2046-03-20", "2046-06-19", "2046-09-18", "2046-12-18",    "2047-03-20", "2047-06-19", "2047-09-18", "2047-12-18",    "2048-03-17", "2048-06-16", "2048-09-15", "2048-12-15",    "2049-03-16", "2049-06-15", "2049-09-21", "2049-12-21",    "2050-03-15", "2050-06-21", "2050-09-20", "2050-12-20",    "2051-03-21", "2051-06-20", "2051-09-19", "2051-12-19",    "2052-03-19", "2052-06-18", "2052-09-17", "2052-12-17"]

def get_dv01(notional, rate, effective, maturity):
    days_to_maturity = (maturity - effective).days
    years_to_maturity = days_to_maturity / 360.0
    dv01_leg_1 = (notional * rate * years_to_maturity) / 10000
    dv01_leg_1 = (dv01_leg_1 * 2) / 100
    return dv01_leg_1

def get_dtcc_file(ref_date: datetime.date, counter: int) -> bytes:
    final_url = base_url.format(ref_date, counter)
    resp = requests.get(final_url)
    if resp.status_code != 200:
        return None
    return resp.content

def create_text(flag,effective_date, event_type, rate, currency, dv01, timestamp):
    rate_percent = round(rate * 100, 7)  # Convert rate to percentage and round to 3sf
    currency_symbol = "£" if currency == "GBP" else ("$" if currency == "USD" else "€")
    dv01_text = f"{currency_symbol}{dv01:.0f}k"
    timestamp_dt = pd.to_datetime(timestamp)
    timestamp_dt_plus_one_hour = timestamp_dt + pd.Timedelta(hours=1)
    timestamp_text = f"Time St\z\az
    amp: {timestamp_dt_plus_one_hour.strftime('%Y-%m-%d %H:%M:%S')[-9:-1]}\n"
    
    text = event_type + " " + currency 
    text = f" {(str(event_type))} {currency} trades at {rate_percent}% in {dv01_text} DV01\n"


    #text = flag+f" {(str(effective_date.strftime('%B'))[:3])} {event_type} trades at {rate_percent}%"
    #text += f" in {dv01_text} DV01 on SDR\n"
    text += timestamp_text
    
    return text

def show_notification(text):
    root = Tk()
    root.overrideredirect(True)
    
    # Set the size of the window
    window_width = 400
    window_height = 200
    
    # Set the window position to bottom left
    position_right = 500
    position_down = root.winfo_screenheight() - window_height - 50

    root.geometry(f"{window_width}x{window_height}+{position_right}+{position_down}")

    # Create a Text widget
    text_widget = Text(root, height=10, width=50, wrap='word', font=("Helvetica", 14))
    text_widget.insert(END, text)
    text_widget.configure(state='normal')  # Make the text widget editable (for copying)
    text_widget.pack(padx=10, pady=10)

    # Add a scrollbar
    scrollbar = Scrollbar(root, command=text_widget.yview)
    text_widget['yscrollcommand'] = scrollbar.set
    scrollbar.pack(side=RIGHT, fill=Y)

    # Close the window after 30 seconds
    root.after(30000, root.destroy)
    
    root.mainloop()

def send_notification(flag,event_type, effective_date, rate, currency, dv01, timestamp):
    if dv01 > 10:  # Only show notification if DV01 is greater than 10
        text = create_text(flag,effective_date, event_type, rate, currency, dv01, timestamp)
        show_notification(text)

def calculate_difference(eff_date_str, exp_date_str):
    eff_date = pd.to_datetime(eff_date_str)
    exp_date = pd.to_datetime(exp_date_str)
    
    # Calculate the difference in months
    diff_months = (exp_date.year - eff_date.year) * 12 + exp_date.month - eff_date.month
    
    # Check if the difference includes a partial month
    if exp_date.day > eff_date.day:
        diff_months += 1

    # Determine if the difference should be expressed in months or years
    if diff_months < 12:
        result = f"{diff_months}m"
    else:
        # Round up to the nearest year
        diff_years = math.ceil(diff_months / 12)
        result = f"{diff_years}y"

    return result

ref_date = datetime.date.today() #- datetime.timedelta(days=3)
counter = 200

def flag_curr(curr):
    if curr=="ZAR":
        return "{SA}"
    if curr=="ILS":
        return "{IS}"
    if curr=="CZK":
        return "{CZ}"
    if curr=="PLN":
        return "{PD}"
    if curr=="HUF":
        return "{HU}"

try:
    while True:
        print(f"Processing counter: {counter}")
        zip_content = get_dtcc_file(ref_date, counter)
        
        if zip_content is None:
            time.sleep(20)
            continue

        with ZipFile(BytesIO(zip_content)) as z:
            file_list = z.namelist()
            
            with z.open(file_list[0]) as f:
                df = pd.read_csv(f)
                #df.to_csv(f'attempt2_counter_{counter}.csv')

                selected_columns = [
                    "Dissemination Identifier",
                    "Action type",
                    "Event type",
                    "Event timestamp",
                    "Effective Date",
                    "Execution Timestamp",
                    "Expiration Date",
                    "Platform identifier",
                    "Notional amount-Leg 1",
                    "Notional currency-Leg 1",
                    "Fixed rate-Leg 1",
                    "Fixed rate-Leg 2",
                    "Package transaction price",
                    "Other payment amount"
                ]

                new_df = df[selected_columns]
                new_df["Notional amount-Leg 1"] = new_df["Notional amount-Leg 1"].fillna('').astype(str).str.replace('[^\d]', '', regex=True)
                new_df["Notional amount-Leg 1"] = pd.to_numeric(new_df["Notional amount-Leg 1"], errors='coerce').fillna(0).astype('int64')

                for idx, row in new_df.iterrows():
                    try:
                        other_payment_amount = float(row['Other payment amount'])
                        is_nan = math.isnan(other_payment_amount)
                    except ValueError:
                        is_nan = False 
                    if (row["Notional currency-Leg 1"] in ["ZAR", "ILS", "CZK", "PLN", "HUF"]) and is_nan:  
                            
                        eff_date = pd.to_datetime(row["Effective Date"])
                        exp_date = pd.to_datetime(row["Expiration Date"])
                        timestamp = row["Execution Timestamp"]
                        timestamp_dt = pd.to_datetime(timestamp)

                        difference = calculate_difference(eff_date, exp_date)
                        notional = row["Notional amount-Leg 1"]
                        rate1 = row['Fixed rate-Leg 1']
                        rate2 = row['Fixed rate-Leg 2']

                        rate = rate2 if pd.isna(rate1) else rate1
                        dv01 = get_dv01(notional, rate, eff_date, exp_date)
                        
                        #print(row["Notional currency-Leg 1"])
                        if row["Notional currency-Leg 1"] == "ZAR":
                            #print("here")
                            dv01= dv01/2.15

                        if row["Notional currency-Leg 1"] == "CZK":
                            #print("here")
                            dv01= dv01*1.2

                        event_type = ""
                        flag = flag_curr(row["Notional currency-Leg 1"])

                        if (str(eff_date.date())) in dates:
                            index = dates.index(str(eff_date.date()))
                            event_type = names[index]
                        elif exp_date == ref_date:
                            event_type = "Spot"
                        else:
                            event_type = str(eff_date)

                        dv01 = float(f"{dv01:.2g}")
                        event_type = event_type + " " + difference
                        if event_type:
                            send_notification(flag,event_type, eff_date, rate, row["Notional currency-Leg 1"], dv01, timestamp)
                            print(f"{event_type} detected: DV01 = {dv01}")

        counter += 1

except Exception as e:
    print(e)
    print(f"Erro: e <GO>")
