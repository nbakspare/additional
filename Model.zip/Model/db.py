import pandas as pd
from dash import Dash, dcc, html, Input, Output, callback, State
import json
import re
import os
import time
from datetime import datetime
from jupyterthemes import jtplot
import matplotlib.pyplot as plt
from arch import arch_model
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
# currently installed theme will be used to
# set plot style if no arguments provided
from pykalman import KalmanFilter 
import numpy as np
import pandas as pd
from numpy import poly1d
from statsmodels.tsa.stattools import adfuller
from sklearn import linear_model
import statsmodels.api as sm
from scipy import signal
import plotly.graph_objs as go
from datetime import timedelta
import dash_table

jtplot.style()

data_ST = (
    pd.read_csv('UW.csv')
)

data_MT = (
    pd.read_csv('MT.csv')
)

data_LT = (
    pd.read_csv('LT.csv')
)

data_W = (
    pd.read_csv('W.csv')
)

#data_kalman = pd.read_csv('DataFinal.csv', index_col ='Dates', parse_dates=True)


external_stylesheets = [
    {
        "href": (
            "https://fonts.googleapis.com/css2?"
            "family=Lato:wght@400;700&display=swap"
        ),
        "rel": "stylesheet",
    },
]
app = Dash(__name__, external_stylesheets=external_stylesheets, suppress_callback_exceptions=True)
app.title = "dash"

card_style = {
    "display": "flex",  # Use flexbox to create a horizontal layout
}

graph_style = {
    "flex": "82%",  # Adjust the width of the graph
}

statistics_style = {
    "flex": "40%",  # Adjust the width of the statistics section
    "padding": "20px",  # Add padding to the section for spacing
}

title_style = {
    "text-align": "center",  # Center align the title text
    "margin-top": "10px",  # Add some space above the title
    "margin-bottom": "10px",  # Add some space below the title
}


tabs_styles = {
    'height': '44px'
}
tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '6px',
    'fontWeight': 'bold'
}

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#119DFF',
    'color': 'white',
    'padding': '6px'
}

def get_freq(x,n,dt):
    '''EXTRACTS TOP THREE FREQUENCIES USING DFT'''
    # Expects x as dataframe, n as integer and dt as positive number
    x = x - sum(x)/len(x)
    assert sum(x)/len(x) < 0.0001 and sum(x)/len(x) > -0.0001
    f, Pxx_den = signal.periodogram(x,1/dt)
    res,i = [],0
    while i < n:
        freq_index = np.argmax(Pxx_den)
        res.append(f[freq_index])
        Pxx_den[freq_index] = min(Pxx_den)
        i += 1
    return res

def find_crossings_to_zero(data):
    crossings = (data.shift(1) >= 0) & (data < 0) | (data.shift(1) < 0) & (data >= 0)
    crossing_dates = data[crossings].index
    return crossing_dates

def find_crossings_to_x(data, x):
    crossings = (data.shift(1) >= x) & (data < x) | (data.shift(1) < x) & (data >= x)
    crossing_indices = data[crossings].index
    return crossing_indices

def generate_html(row):
    blue = row['Blue']
    res = (eval(blue))[0]
    exp = row['Spread']
    exp_ma = (eval(exp))[0]
    ide = row['Name']
    spread = row['End_Spread']
    tp = row['Take_Profit']
    tn = row['Total_Num']
    wr = row['Win_Ratio']
    total_pnl = row['Cum_PNL']
    average_time = row['Avg_Time']
    max_drawdown = row['Max_Drawdown']
    average_pnl = row['Average_PNL']
    max_pnl = row['Max_PNL']
    #time_stop = row['Time_Stop']
    #fourier = row['Fourier']
    #days_until_fourier = row['ttof']
    #lookback = row['Lookback']
    #zscore = row['zscore']

    return html.Div(
        className="wrapper",
        children=[
            html.Div(
                className="card",
                style=card_style,  # Apply the card style with flexbox
                children=[
                    html.Div(
                        style=graph_style,  # Apply the graph styles
                        children=[
                            dcc.Graph(
                                id="price-chart",
                                config={"displayModeBar": False},
                                figure={
                                    "data": [
                                        {
                                            "x": list(range(len(res))),
                                            "y": res,
                                            "type": "lines",
                                            "name": "Spread"
                                        },
                                        {
                                            "x": list(range(len(exp_ma))),
                                            "y": exp_ma,
                                            "type": "lines",
                                            "name": "Exp MA"
                                        }
                                    ],
                                    "layout": {
                                        "title": ide,
                                        "xaxis": {"title": "Days"},
                                        "yaxis": {"title": "Spread"},
                                        "legend": {"x": 1, "y": 1},
                                        "margin": {"l": 40, "r": 40, "t": 40, "b": 40}
                                    }
                                }
                            ),
                        ],
                    ),  
                    html.Div(
                        style=statistics_style,  # Apply the statistics section styles
                        children=[
                            html.H3("Statistics"),
                            html.Ul([
                                html.Li([html.Strong("Name: "), html.Span(str(ide), style={"color": "blue"})]),
                                html.Li([html.Strong("Win Rate: "), html.Span(str(wr), style={"color": "blue"})]),
                                html.Li([html.Strong("Entry Level: "), html.Span((str(spread))[:5] + " bps", style={"color": "blue"})]),
                                html.Li([html.Strong("Average PnL: "), html.Span(str(average_pnl) + " bps", style={"color": "blue"})]),
                                html.Li([html.Strong("Total Number of Trades: "), html.Span(str(tn), style={"color": "blue"})]),
                                html.Li([html.Strong("Take Profit: "), html.Span((str(tp))[:5]+ " bps", style={"color": "blue"})]),
                                #html.Li([html.Strong("Fourier date: "), html.Span(str(fourier), style={"color": "blue"})]),
                                html.Li([html.Strong("Max PnL: "), html.Span(str(max_pnl)[:5]+ " bps", style={"color": "blue"})]),
                                #html.Li([html.Strong("Time Stop: "), html.Span(str(time_stop), style={"color": "blue"})]),
                                html.Li([html.Strong("Total PnL: "), html.Span(str(total_pnl)+ " bps", style={"color": "blue"})]),
                                html.Li([html.Strong("Max Drawdown: "), html.Span(str(max_drawdown)+ " bps", style={"color": "blue"})]),
                                html.Li([html.Strong("Average time of trade: "), html.Span(str(average_time), style={"color": "blue"})]),
                                #html.Li([html.Strong("Lookback: "), html.Span(str(lookback), style={"color": "blue"})]),
                                #html.Li([html.Strong("Z-score: "), html.Span(str(zscore), style={"color": "blue"})]),
                            ])
                        ]
                    )
                ]
            )
        ]
    )
# Create an empty list to store the generated HTML code for each row
ST_rows = []

# Iterate over each row in the DataFrame and generate the HTML code
for index, row in data_ST.iterrows():
    html_code = generate_html(row)
    ST_rows.append(html_code)

# Create an empty list to store the generated HTML code for each row
MT_rows = []

# Iterate over each row in the DataFrame and generate the HTML code
for index, row in data_MT.iterrows():
    html_code = generate_html(row)
    MT_rows.append(html_code)

# Create an empty list to store the generated HTML code for each row
LT_rows = []

# Iterate over each row in the DataFrame and generate the HTML code
for index, row in data_LT.iterrows():
    html_code = generate_html(row)
    LT_rows.append(html_code)

# Create an empty list to store the generated HTML code for each row
W_rows = []

# Iterate over each row in the DataFrame and generate the HTML code
for index, row in data_W.iterrows():
    html_code = generate_html(row)
    W_rows.append(html_code)



app.layout = html.Div(
    children=[
        html.Div(
            children=[
                html.H1(
                    children="Dashboard" , className="header-title", style={"padding": "50px"} 
                ),
                dcc.Tabs(id="tabs-mk", value='tab-1', children=[
                    dcc.Tab(label='XMKT - ST', value='ST', style=tab_style, selected_style=tab_selected_style),
                    dcc.Tab(label='XMKT - MT', value='MT', style=tab_style, selected_style=tab_selected_style),
                    dcc.Tab(label='XMKT - LT', value='LT', style=tab_style, selected_style=tab_selected_style),
                    dcc.Tab(label='XMKT - W', value='W', style=tab_style, selected_style=tab_selected_style),
                ], style=tabs_styles),
            ],
            className="header",
        ),
        #html.Div(children=html_rows),
        html.Div(id='tabs-content')
    ]
)


@callback(Output('tabs-content', 'children'),
              Input('tabs-mk', 'value'))


def render_content(tab):
    if tab == 'ST':
        return html.Div(children=ST_rows),
    elif tab == 'MT':
        return html.Div(children=MT_rows),
    elif tab == 'LT':
        return html.Div(children=LT_rows),
    elif tab == 'W':
        return html.Div(children=W_rows)

if __name__ == "__main__":
    app.run_server(debug=True)